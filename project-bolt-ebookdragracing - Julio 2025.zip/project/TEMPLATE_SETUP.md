# 🚀 AG-42 Racing - Template para Landing Pages

## 📋 Cómo usar este template para crear nuevas páginas

### 1. Crear un repositorio template en GitHub

1. **Sube todo el código a GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Initial template setup"
   git remote add origin https://github.com/tu-usuario/ag42-racing-template.git
   git push -u origin main
   ```

2. **Convierte el repo en template:**
   - Ve a Settings del repositorio
   - Marca "Template repository"
   - Guarda los cambios

### 2. Para crear una nueva página web:

1. **Usa el template:**
   - Ve a tu repositorio template
   - Click en "Use this template"
   - Crea un nuevo repositorio

2. **Personaliza el contenido:**
   - Modifica `src/components/Hero.tsx` (título, subtítulo)
   - Actualiza `src/components/Footer.tsx` (redes sociales, contacto)
   - Cambia las imágenes en `/public/`
   - Ajusta colores en `tailwind.config.js`

### 3. Variables a personalizar por proyecto:

#### En `src/components/Hero.tsx`:
```typescript
// Cambiar título principal
<h1>TU NUEVO TÍTULO AQUÍ</h1>

// Cambiar subtítulo
<p>Tu nueva descripción del producto/servicio</p>

// Cambiar autor
<h2>Por <span>TU NOMBRE</span> – TU MARCA</h2>
```

#### En `src/components/Footer.tsx`:
```typescript
// Cambiar redes sociales
<motion.a href="https://facebook.com/tu-pagina">
<motion.a href="https://instagram.com/tu-cuenta">
<motion.a href="https://youtube.com/@tu-canal">

// Cambiar email de contacto
ayulgabriel@gmail.com → tu-email@gmail.com
```

#### En `netlify/functions/crearPago.js`:
```javascript
// Cambiar datos del producto
title: 'Tu Nuevo Producto',
price: 9999, // Tu precio
description: 'Descripción de tu producto'
```

#### En `index.html`:
```html
<!-- Cambiar título de la página -->
<title>Tu Marca | Tu Producto</title>
```

### 4. Configuración de pagos (MercadoPago):

1. **Obtén tus credenciales:**
   - Ve a https://mercadopago.com.ar/developers
   - Crea una aplicación
   - Copia tu Access Token

2. **Configura en Netlify:**
   - Variables de entorno → `MERCADOPAGO_ACCESS_TOKEN`
   - Pega tu token real

### 5. Configuración de emails (Netlify Forms):

El sistema de consultas ya está configurado y funcionará automáticamente en Netlify.

### 6. Personalización de colores:

En `tailwind.config.js`:
```javascript
colors: {
  'race-black': '#000000',    // Color de fondo
  'race-red': '#FF0000',      // Color principal (cambiar por tu color)
  'race-white': '#FFFFFF',    // Color de texto
  'race-gray': '#1a1a1a',     // Color secundario
},
```

### 7. Estructura de archivos clave:

```
src/
├── components/
│   ├── Hero.tsx              # Sección principal
│   ├── Footer.tsx            # Contacto y compra
│   ├── Navbar.tsx            # Navegación
│   ├── ContactForm.tsx       # Formulario de consultas
│   ├── AutoPaymentButton.tsx # Sistema de pagos
│   └── [OtrasSeciones].tsx   # Contenido específico
├── index.css                 # Estilos globales
└── App.tsx                   # Estructura principal

netlify/functions/
├── crearPago.js             # Lógica de pagos
└── webhook.js               # Notificaciones de pago

public/
└── [imagenes]               # Todas las imágenes del sitio
```

### 8. Checklist para nuevo proyecto:

- [ ] Cambiar título y descripción en Hero
- [ ] Actualizar información de contacto
- [ ] Reemplazar todas las imágenes
- [ ] Configurar credenciales de MercadoPago
- [ ] Ajustar precio del producto
- [ ] Personalizar colores de marca
- [ ] Actualizar enlaces de redes sociales
- [ ] Modificar contenido de las secciones
- [ ] Cambiar favicon y metadatos
- [ ] Probar sistema de pagos en modo sandbox

### 9. Deploy automático:

1. **Conecta con Netlify:**
   - Conecta tu repositorio a Netlify
   - Deploy automático en cada push

2. **Configura variables de entorno:**
   - `MERCADOPAGO_ACCESS_TOKEN`
   - Cualquier otra variable necesaria

### 10. Mantenimiento:

- Las funciones serverless ya están optimizadas
- El sistema de emails funciona sin configuración adicional
- Los estilos son completamente responsivos
- Todas las animaciones están incluidas

## 🎨 Personalización Rápida

Para cambiar rápidamente la identidad visual:

1. **Colores:** Modifica `race-red` en `tailwind.config.js`
2. **Fuentes:** Cambia las fuentes en `index.html` y `tailwind.config.js`
3. **Logo:** Reemplaza las imágenes en `/public/`
4. **Contenido:** Edita los componentes en `/src/components/`

## 🚀 Ventajas de este template:

✅ Sistema de pagos completo con MercadoPago
✅ Formulario de contacto funcional
✅ Diseño responsive y profesional
✅ Animaciones y efectos visuales
✅ SEO optimizado
✅ Deploy automático con Netlify
✅ Código modular y fácil de mantener

## 📞 Soporte

Si necesitas ayuda personalizando el template, contacta a través de los canales oficiales de AG-42 Racing.