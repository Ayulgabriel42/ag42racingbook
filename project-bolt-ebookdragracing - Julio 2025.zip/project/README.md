# AG-42 Racing eBook Landing Page

## Configuración de MercadoPago

Para que el sistema de pagos funcione correctamente, necesitas configurar las siguientes variables de entorno en Netlify:

### Variables de Entorno Requeridas

1. Ve a tu dashboard de Netlify
2. Selecciona tu sitio
3. Ve a "Site settings" > "Environment variables"
4. Agrega las siguientes variables:

```
MERCADOPAGO_ACCESS_TOKEN=APP_USR-6011669780819239-062608-4b8fe899a4131a5fa569fa3ac5d8f38b-77396252
```

## Configuración del Sistema de Emails (Consultas)

Para que el formulario de consultas envíe emails reales a tu casilla, necesitas configurar EmailJS:

### Paso 1: Crear cuenta en EmailJS

1. Ve a [EmailJS.com](https://www.emailjs.com/) y crea una cuenta gratuita
2. Verifica tu email

### Paso 2: Configurar servicio de email

1. En el dashboard de EmailJS, ve a "Email Services"
2. Haz click en "Add New Service"
3. Selecciona "Gmail" (recomendado)
4. Conecta tu cuenta de Gmail (ayulgabriel@gmail.com)
5. Copia el **Service ID** que se genera

### Paso 3: Crear template de email

1. Ve a "Email Templates"
2. Haz click en "Create New Template"
3. Usa este contenido para el template:

**Subject:** Nueva consulta de {{from_name}} - AG-42 Racing eBook

**Content:**
```
Hola Gabriel,

Has recibido una nueva consulta desde el eBook de AG-42 Racing:

Nombre: {{from_name}}
Email: {{from_email}}
Fecha: {{timestamp}}

Mensaje:
{{message}}

---
Información técnica:
IP: {{user_ip}}
User Agent: {{user_agent}}

Puedes responder directamente a este email.

Saludos,
Sistema AG-42 Racing
```

4. Guarda el template y copia el **Template ID**

### Paso 4: Obtener claves de API

1. Ve a "Account" > "General"
2. Copia tu **Public Key**
3. Ve a "Account" > "Security"
4. Genera y copia tu **Private Key**

### Paso 5: Configurar variables en Netlify

Agrega estas variables de entorno en Netlify:

```
EMAILJS_SERVICE_ID=tu_service_id_aqui
EMAILJS_TEMPLATE_ID=tu_template_id_aqui
EMAILJS_PUBLIC_KEY=tu_public_key_aqui
EMAILJS_PRIVATE_KEY=tu_private_key_aqui
```

### Método Alternativo: Webhook (Opcional)

Si prefieres usar un webhook en lugar de EmailJS:

1. Crea una cuenta en [Zapier](https://zapier.com/) o [Make](https://make.com/)
2. Crea un webhook que envíe emails a tu Gmail
3. Agrega la variable de entorno:

```
WEBHOOK_URL=https://hooks.zapier.com/hooks/catch/TU_WEBHOOK_ID/
```

### Credenciales de MercadoPago Configuradas

- **Access Token**: `APP_USR-6011669780819239-062608-4b8fe899a4131a5fa569fa3ac5d8f38b-77396252`
- **Public Key**: `APP_USR-36c41059-27dc-4083-b2e9-a611cf93b6cd`
- **User ID**: `77396252`
- **Client ID**: `6011669780819239`
- **Client Secret**: `oeDl75KdlnyPOo832NZfLXcSQ7eXdwEj`

### Configuración de Webhooks (Opcional)

Si quieres recibir notificaciones automáticas de los pagos:

1. En tu aplicación de MercadoPago, ve a "Webhooks"
2. Agrega la URL: `https://tu-sitio.netlify.app/.netlify/functions/webhook`
3. Selecciona los eventos que quieres recibir (especialmente "Pagos")

### URLs de Retorno

El sistema está configurado para redirigir automáticamente a los usuarios después del pago:

- **Pago exitoso**: `/?payment=success&status=approved`
- **Pago fallido**: `/?payment=failure&status=rejected`
- **Pago pendiente**: `/?payment=pending&status=pending`

### Desarrollo Local

Para probar en desarrollo local:

1. Instala Netlify CLI: `npm install -g netlify-cli`
2. Ejecuta: `netlify dev`
3. Configura las variables de entorno en un archivo `.env`:
   ```
   MERCADOPAGO_ACCESS_TOKEN=APP_USR-6011669780819239-062608-4b8fe899a4131a5fa569fa3ac5d8f38b-77396252
   EMAILJS_SERVICE_ID=tu_service_id
   EMAILJS_TEMPLATE_ID=tu_template_id
   EMAILJS_PUBLIC_KEY=tu_public_key
   EMAILJS_PRIVATE_KEY=tu_private_key
   ```

### Configuración en Netlify Dashboard

**IMPORTANTE**: Para que tanto los pagos como los emails funcionen en producción, debes configurar todas las variables de entorno en Netlify:

1. Ve a tu sitio en Netlify Dashboard
2. Site settings → Environment variables
3. Agrega todas las variables mencionadas arriba

### Notas Importantes

- El sistema acepta pagos en pesos argentinos (ARS)
- Permite hasta 12 cuotas sin interés
- Incluye todos los métodos de pago de MercadoPago
- Los usuarios son redirigidos automáticamente después del pago
- El acceso al eBook se otorga inmediatamente después del pago exitoso
- **Precio actual**: $1 ARS (precio de prueba)
- Los emails de consulta se envían a: ayulgabriel@gmail.com

### Funcionalidades del Sistema

1. **Sistema de Pagos**
   - Creación automática de preferencias de pago
   - Redirección automática a MercadoPago
   - Detección automática de pagos exitosos
   - Acceso inmediato al eBook después del pago
   - Persistencia del estado de pago en localStorage

2. **Sistema de Consultas**
   - Formulario de contacto con validación
   - Envío de emails automático a ayulgabriel@gmail.com
   - Validación de formato de email
   - Límite de 1000 caracteres en mensajes
   - Respuesta automática de confirmación

### Deployment

El sitio se despliega automáticamente en Netlify. Solo asegúrate de configurar todas las variables de entorno antes de usar las funcionalidades.

### Troubleshooting

**Problemas con pagos:**
1. Verifica que la variable `MERCADOPAGO_ACCESS_TOKEN` esté configurada en Netlify
2. Revisa los logs de las funciones serverless en Netlify
3. Asegúrate de que tu cuenta de MercadoPago esté activa y verificada

**Problemas con emails:**
1. Verifica que todas las variables de EmailJS estén configuradas correctamente
2. Revisa los logs de la función `enviarConsulta` en Netlify
3. Asegúrate de que el servicio de EmailJS esté activo
4. Verifica que el template de EmailJS esté configurado correctamente

### Testing

- El sistema incluye un botón de prueba en desarrollo local para simular pagos
- El precio está configurado en $1 ARS para facilitar las pruebas
- Los emails se pueden probar directamente desde el formulario de consultas