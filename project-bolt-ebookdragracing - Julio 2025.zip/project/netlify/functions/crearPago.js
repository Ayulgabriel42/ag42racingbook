// Función serverless para crear pagos con MercadoPago
// Usa fetch nativo de Node.js 18+ (sin dependencias externas)

export const handler = async (event, context) => {
  // Configurar CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Manejar preflight request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Solo permitir POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    console.log('=== INICIO CREACIÓN DE PAGO ===');
    console.log('Event body:', event.body);
    console.log('Environment variables check:', {
      hasAccessToken: !!process.env.MERCADOPAGO_ACCESS_TOKEN,
      nodeVersion: process.version,
      runtime: context.awsRequestId ? 'AWS Lambda' : 'Unknown'
    });

    // Validar que el body existe
    if (!event.body) {
      console.error('❌ No body provided in request');
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Request body is required' })
      };
    }

    let requestData;
    try {
      requestData = JSON.parse(event.body);
    } catch (parseError) {
      console.error('❌ Error parsing request body:', parseError);
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid JSON in request body' })
      };
    }

    const { title, price } = requestData;
    
    // Validar datos de entrada
    if (!title || !price) {
      console.error('❌ Missing required fields:', { title, price });
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Title and price are required' })
      };
    }
    
    // Tu Access Token de MercadoPago
    const accessToken = process.env.MERCADOPAGO_ACCESS_TOKEN || 'APP_USR-6011669780819239-062608-4b8fe899a4131a5fa569fa3ac5d8f38b-77396252';
    
    console.log('Access token configured:', !!accessToken);
    console.log('Access token preview:', accessToken ? accessToken.substring(0, 20) + '...' : 'NOT SET');
    
    if (!accessToken) {
      console.error('❌ MercadoPago access token not configured');
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'MercadoPago access token not configured. Please check environment variables in Netlify dashboard.' 
        })
      };
    }

    // Obtener la URL base del sitio
    const siteUrl = process.env.URL || event.headers.origin || event.headers.host || 'https://ebook42.netlify.app';
    const baseUrl = siteUrl.startsWith('http') ? siteUrl : `https://${siteUrl}`;
    
    console.log('Site URL:', baseUrl);
    console.log('Creating payment preference for:', { title, price });

    // Crear la preferencia de pago optimizada
    const preference = {
      items: [
        {
          id: 'ebook-ag42-racing',
          title: title || 'eBook: 402 Metros. Una Pasión. Un Estilo de Vida.',
          description: 'eBook completo sobre carreras de 1/4 de milla por Gabriel Ayul - AG-42 Racing Parts',
          unit_price: parseFloat(price) || 7900,
          quantity: 1,
          currency_id: 'ARS',
          category_id: 'digital_content'
        }
      ],
      back_urls: {
        success: `${baseUrl}/?payment=success&status=approved`,
        failure: `${baseUrl}/?payment=failure&status=rejected`,
        pending: `${baseUrl}/?payment=pending&status=pending`
      },
      auto_return: 'approved',
      statement_descriptor: 'AG-42 Racing',
      external_reference: `ebook_ag42_${Date.now()}`,
      expires: false,
      payment_methods: {
        installments: 12,
        default_installments: 1
      },
      notification_url: `${baseUrl}/.netlify/functions/webhook`
    };

    console.log('📤 Sending preference to MercadoPago API...');

    // Usar fetch nativo con timeout manual
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout')), 25000);
    });

    const fetchPromise = fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'X-Idempotency-Key': `ebook_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        'User-Agent': 'AG42Racing/1.0'
      },
      body: JSON.stringify(preference)
    });

    let mpResponse;
    try {
      mpResponse = await Promise.race([fetchPromise, timeoutPromise]);
    } catch (fetchError) {
      console.error('❌ Fetch error:', fetchError);
      
      if (fetchError.message === 'Request timeout') {
        return {
          statusCode: 408,
          headers,
          body: JSON.stringify({ 
            error: 'Request timeout. MercadoPago API took too long to respond.' 
          })
        };
      }
      
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Network error connecting to MercadoPago API',
          details: fetchError.message
        })
      };
    }

    console.log('MercadoPago response status:', mpResponse.status);
    console.log('MercadoPago response ok:', mpResponse.ok);

    const responseText = await mpResponse.text();
    console.log('MercadoPago raw response length:', responseText.length);
    console.log('MercadoPago raw response preview:', responseText.substring(0, 200));

    if (!responseText || responseText.trim() === '') {
      console.error('❌ Empty response from MercadoPago');
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Empty response from MercadoPago API' 
        })
      };
    }

    let data;
    try {
      data = JSON.parse(responseText);
    } catch (parseError) {
      console.error('❌ Error parsing MercadoPago response:', parseError);
      console.error('❌ Response content:', responseText.substring(0, 500));
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Invalid JSON response from MercadoPago API', 
          details: responseText.substring(0, 200) 
        })
      };
    }

    if (!mpResponse.ok) {
      console.error('❌ MercadoPago API Error:', {
        status: mpResponse.status,
        statusText: mpResponse.statusText,
        data: data
      });
      
      return {
        statusCode: mpResponse.status,
        headers,
        body: JSON.stringify({ 
          error: 'Error from MercadoPago API', 
          details: data,
          status: mpResponse.status,
          statusText: mpResponse.statusText
        })
      };
    }

    if (!data.init_point) {
      console.error('❌ No init_point in response:', data);
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Invalid response structure from MercadoPago API',
          details: 'Missing init_point in response'
        })
      };
    }

    console.log('✅ Payment preference created successfully!');
    console.log('Preference ID:', data.id);
    console.log('Init point:', data.init_point);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        init_point: data.init_point,
        preference_id: data.id,
        sandbox_init_point: data.sandbox_init_point || null
      })
    };

  } catch (error) {
    console.error('❌ Unexpected error creating payment:', error);
    console.error('Error name:', error.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error occurred while processing payment', 
        details: error.message,
        errorType: error.name,
        timestamp: new Date().toISOString()
      })
    };
  }
};