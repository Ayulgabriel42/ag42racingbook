// Webhook para recibir notificaciones de MercadoPago
// Usa solo APIs nativas de Node.js

export const handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    console.log('=== WEBHOOK NOTIFICATION ===');
    console.log('Headers:', event.headers);
    console.log('Body:', event.body);

    if (!event.body) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'No body provided' })
      };
    }

    const body = JSON.parse(event.body);
    console.log('Parsed notification:', body);
    
    // Verificar que es una notificación de pago
    if (body.type === 'payment') {
      console.log('✅ Payment notification received:', {
        id: body.data?.id,
        action: body.action,
        type: body.type
      });
      
      // Aquí puedes agregar lógica adicional como:
      // - Guardar el pago en una base de datos
      // - Enviar email de confirmación
      // - Actualizar el estado del usuario
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          status: 'ok',
          message: 'Payment notification processed'
        })
      };
    }

    console.log('ℹ️ Non-payment notification ignored:', body.type);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        status: 'ignored',
        message: 'Non-payment notification'
      })
    };

  } catch (error) {
    console.error('❌ Webhook error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        details: error.message
      })
    };
  }
};