/**
 * Utility functions for handling file downloads from Google Drive
 */

export const downloadFromGoogleDrive = (fileId: string, fileName: string = 'document.pdf') => {
  // Method 1: Try direct download
  const directDownloadUrl = `https://drive.google.com/uc?export=download&id=${fileId}`;
  
  // Create a temporary link element
  const link = document.createElement('a');
  link.href = directDownloadUrl;
  link.download = fileName;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  
  // Add to DOM temporarily
  document.body.appendChild(link);
  
  // Trigger download
  link.click();
  
  // Clean up
  document.body.removeChild(link);
  
  return directDownloadUrl;
};

export const openGoogleDriveFile = (fileId: string) => {
  const viewUrl = `https://drive.google.com/file/d/${fileId}/view?usp=drive_link`;
  window.open(viewUrl, '_blank', 'noopener,noreferrer');
  return viewUrl;
};

export const getGoogleDriveDownloadUrl = (fileId: string) => {
  return `https://drive.google.com/uc?export=download&id=${fileId}`;
};

export const getGoogleDriveViewUrl = (fileId: string) => {
  return `https://drive.google.com/file/d/${fileId}/view?usp=drive_link`;
};

// Updated file ID for the new PDF
export const EBOOK_FILE_ID = '1mLkgP2Rpl7ZsSYN4TPTyiI9sOR5Zul1V';