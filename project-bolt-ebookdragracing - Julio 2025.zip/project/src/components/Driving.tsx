import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Printer as Steering, Play } from 'lucide-react';
import AnimatedSection from './AnimatedSection';

interface Technique {
  id: string;
  name: string;
  description: string;
  animation: string;
  videoUrl: string | null;
}

const techniques: Technique[] = [
  {
    id: 'launch',
    name: 'Técnica de Lanzamiento',
    description: 'Maximiza la tracción en el momento de la salida para un arranque explosivo, manteniendo las RPM óptimas.',
    animation: 'launch',
    videoUrl: 'https://i.gifer.com/AsM9.mp4'
  },
  {
    id: 'shifting',
    name: 'Cambios Perfectos',
    description: 'Realiza cambios de marcha en el momento preciso para mantener el motor en su rango de potencia óptimo.',
    animation: 'shifting',
    videoUrl: '/tumblr_ma5vyyuxfw1r2ajbko1_500 copy copy.gif'
  },
  {
    id: 'line',
    name: 'Mantener la Línea',
    description: 'Conserva una trayectoria recta durante toda la carrera para evitar pérdidas de velocidad y descalificaciones.',
    animation: 'line',
    videoUrl: null
  },
  {
    id: 'braking',
    name: 'Frenado Efectivo',
    description: 'Aplica los frenos en el momento correcto al final de la carrera para detener el vehículo con seguridad.',
    animation: 'braking',
    videoUrl: 'https://i.gifer.com/RB4H.mp4'
  }
];

const Driving: React.FC = () => {
  const [selectedTechnique, setSelectedTechnique] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleSelectTechnique = (id: string) => {
    setSelectedTechnique(id);
    setIsPlaying(true);
    
    // Reset animation after playing
    setTimeout(() => {
      setIsPlaying(false);
    }, 3000);
  };

  return (
    <AnimatedSection title="TÉCNICAS DE CONDUCCIÓN" id="driving">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <p className="mb-4">
            Dominar las técnicas adecuadas de conducción puede reducir significativamente tus tiempos, 
            incluso con un vehículo de potencia moderada. Estas habilidades se desarrollan con la práctica
            constante y la comprensión de la física involucrada en cada maniobra.
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
            {techniques.map((tech) => (
              <motion.button
                key={tech.id}
                className={`p-3 rounded-lg font-bebas text-center transition-all ${
                  selectedTechnique === tech.id 
                    ? 'bg-race-red text-white neon-border' 
                    : 'bg-race-gray/60 hover:bg-race-gray'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSelectTechnique(tech.id)}
              >
                {tech.name}
              </motion.button>
            ))}
          </div>
        </div>

        <motion.div 
          className="bg-race-gray rounded-lg p-6 border border-race-red h-80 flex flex-col items-center justify-center relative overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {selectedTechnique ? (
            <>
              {techniques.filter(t => t.id === selectedTechnique).map((tech) => (
                <div key={tech.id} className="text-center">
                  <h4 className="font-bebas text-2xl text-race-red mb-4">{tech.name}</h4>
                  <p className="mb-6">{tech.description}</p>
                  
                  {/* Animation placeholder */}
                  <motion.div
                    className="relative w-64 h-32 mx-auto bg-black rounded-lg overflow-hidden"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    {tech.id === 'launch' && tech.videoUrl && (
                      <video
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="absolute inset-0 w-full h-full object-cover"
                        key={tech.id}
                      >
                        <source src={tech.videoUrl} type="video/mp4" />
                      </video>
                    )}
                    
                    {tech.id === 'shifting' && (
                      <img
                        src="/tumblr_ma5vyyuxfw1r2ajbko1_500 copy copy.gif"
                        alt="Técnica de cambios"
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    )}
                    
                    {tech.id === 'line' && (
                      <img
                        src="/race-start.gif"
                        alt="Mantener la línea"
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    )}
                    
                    {tech.id === 'braking' && (
                      <video
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="absolute inset-0 w-full h-full object-cover"
                        key={tech.id}
                      >
                        <source src="https://i.gifer.com/RB4H.mp4" type="video/mp4" />
                      </video>
                    )}
                    
                  </motion.div>
                </div>
              ))}
            </>
          ) : (
            <div className="text-center">
              <p className="font-bebas text-xl mb-4">Selecciona una técnica para ver la animación</p>
              <Steering size={48} className="text-race-red mx-auto animate-pulse" />
            </div>
          )}
        </motion.div>
      </div>
    </AnimatedSection>
  );
};

export default Driving;