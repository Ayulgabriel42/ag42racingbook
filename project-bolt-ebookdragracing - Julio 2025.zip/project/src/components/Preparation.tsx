import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings } from 'lucide-react';
import AnimatedSection from './AnimatedSection';

interface EngineModification {
  id: string;
  name: string;
  stockPerformance: number;
  modifiedPerformance: number;
  description: string;
  details: string;
}

const modifications: EngineModification[] = [
  {
    id: 'turbo',
    name: 'TURBO',
    stockPerformance: 30,
    modifiedPerformance: 90,
    description: 'Incrementa la potencia forzando más aire en los cilindros para una mejor combustión.',
    details: 'Un turbo bien dimensionado puede aumentar la potencia entre 40-100% dependiendo del motor base.'
  },
  {
    id: 'intake',
    name: 'Sistema de Admisión',
    stockPerformance: 40,
    modifiedPerformance: 80,
    description: 'Un sistema de admisión de alto flujo permite que entre más aire al motor.',
    details: 'Incluye filtro de aire deportivo, ductos de mayor diámetro y caja de resonancia optimizada.'
  },
  {
    id: 'exhaust',
    name: 'Escape Deportivo',
    stockPerformance: 45,
    modifiedPerformance: 75,
    description: 'Reduce la contrapresión y mejora la respuesta del motor.',
    details: 'Sistema completo desde colectores hasta escape final, optimizado para máximo flujo.'
  },
  {
    id: 'ecu',
    name: 'Reprogramación ECU',
    stockPerformance: 35,
    modifiedPerformance: 85,
    description: 'Optimiza los parámetros del motor para maximizar potencia y respuesta.',
    details: 'Ajuste de mapas de inyección, encendido, boost y limitadores para máximo rendimiento.'
  },
  {
    id: 'injectors',
    name: 'Inyectores de Alto Flujo',
    stockPerformance: 50,
    modifiedPerformance: 95,
    description: 'Permiten suministrar más combustible para soportar mayor potencia.',
    details: 'Esenciales cuando se aumenta significativamente la potencia del motor.'
  },
  {
    id: 'internals',
    name: 'Pistones - Bielas - Cigüeñal',
    stockPerformance: 25,
    modifiedPerformance: 100,
    description: 'Pistones forjados, bielas reforzadas y cigüeñal balanceado.',
    details: 'La base sólida para cualquier preparación seria de alta potencia.'
  }
];

const Preparation: React.FC = () => {
  const [selectedMod, setSelectedMod] = useState<string | null>(null);

  return (
    <AnimatedSection title="PREPARACIÓN DE MOTORES" id="preparation">
      <div className="mb-8">
        <div 
          className="relative p-6 rounded-lg border border-race-red mb-8 overflow-hidden"
          style={{
            backgroundImage: `url('/83202423_137451944381473_4784903909195907072_n.jpg')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
        >
          {/* Dark overlay for better text readability */}
          <div className="absolute inset-0 bg-black/80 rounded-lg"></div>
          
          {/* Content with relative positioning to appear above overlay */}
          <div className="relative z-10">
            <h4 className="font-bebas text-xl text-race-red mb-3">LA CIENCIA DE LA POTENCIA</h4>
            <p className="text-lg leading-relaxed mb-4 text-white">
              La preparación de un motor de 1/4 de milla es un arte que combina conocimiento técnico, 
              experiencia práctica y una comprensión profunda de la física de la combustión interna. 
              Cada modificación debe ser cuidadosamente planificada y ejecutada.
            </p>
            <p className="text-base text-gray-300">
              <strong>Principio fundamental:</strong> No se trata solo de agregar potencia, sino de crear 
              un conjunto armonioso donde cada componente trabaje en perfecta sincronía para entregar 
              máximo rendimiento y confiabilidad.
            </p>
          </div>
        </div>
      </div>

      <p className="text-center mb-8 text-lg">
        Selecciona una modificación para ver su impacto en el rendimiento y detalles técnicos
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
            {modifications.map((mod) => (
              <motion.button
                key={mod.id}
                className={`p-4 rounded-lg font-bebas text-center transition-all border-2 ${
                  selectedMod === mod.id 
                    ? 'bg-race-red text-white neon-border border-race-red' 
                    : 'bg-race-gray/60 hover:bg-race-gray border-gray-600 hover:border-race-red'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedMod(mod.id)}
              >
                <div className="text-sm">{mod.name}</div>
              </motion.button>
            ))}
          </div>

          {selectedMod && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-race-gray p-6 rounded-lg border border-race-red"
            >
              {modifications.filter(mod => mod.id === selectedMod).map((mod) => (
                <div key={mod.id}>
                  <h4 className="font-bebas text-2xl mb-3 text-race-red">{mod.name}</h4>
                  <p className="mb-4 text-lg">{mod.description}</p>
                  <p className="mb-6 text-sm text-gray-300 italic">{mod.details}</p>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Configuración Stock</span>
                        <span className="text-sm font-bold">{mod.stockPerformance}%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-3">
                        <div 
                          className="bg-gray-400 h-3 rounded-full transition-all duration-1000" 
                          style={{ width: `${mod.stockPerformance}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Con Modificación</span>
                        <span className="text-sm font-bold text-race-red">{mod.modifiedPerformance}%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-3">
                        <motion.div 
                          className="bg-race-red h-3 rounded-full neon-border" 
                          initial={{ width: `${mod.stockPerformance}%` }}
                          animate={{ width: `${mod.modifiedPerformance}%` }}
                          transition={{ duration: 1, delay: 0.5 }}
                        ></motion.div>
                      </div>
                    </div>
                    
                    <div className="bg-race-black/50 p-3 rounded border-l-4 border-race-red">
                      <p className="text-sm">
                        <strong>Ganancia de rendimiento:</strong> +{mod.modifiedPerformance - mod.stockPerformance}%
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </div>

        <motion.div
          className="relative h-64 md:h-80 bg-black rounded-lg overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <img 
            src="/263323742_4795859357103735_8443930746246232518_n.jpg"
            alt="Motor de competición con inyectores de alto rendimiento"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-black/70"></div>
          <div className="absolute bottom-0 left-0 w-full p-6">
            <h4 className="font-bebas text-2xl text-race-white mb-2">
              MOTORES DE COMPETICION - DESARROLLO SIN LIMITES
            </h4>
            <p className="text-sm text-gray-300 mb-2">
              Los desarrollos de los motores del 1/4 de milla son muy amplios, mas allá de los reglamentos, el tipo de preparación es completamente libre, dando lugar a desarrollos de diferentes tipos y en constante evolución mecánica y electrónica.
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatedSection>
  );
};

export default Preparation;