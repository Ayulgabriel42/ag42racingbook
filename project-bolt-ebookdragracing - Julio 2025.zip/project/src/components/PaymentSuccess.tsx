import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, BookOpen, ExternalLink } from 'lucide-react';

interface PaymentSuccessProps {
  isVisible: boolean;
  onAccessEbook: () => void;
}

const PaymentSuccess: React.FC<PaymentSuccessProps> = ({ 
  isVisible, 
  onAccessEbook
}) => {
  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.8, y: 50 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.8, y: 50 }}
        className="bg-race-gray p-8 rounded-lg border-2 border-green-500 max-w-md w-full text-center relative neon-border"
        style={{ boxShadow: '0 0 20px rgba(34, 197, 94, 0.5)' }}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
        >
          <CheckCircle size={80} className="text-green-500 mx-auto mb-6" />
        </motion.div>
        
        <motion.h2 
          className="font-bebas text-4xl text-green-500 mb-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          ¡PAGO EXITOSO!
        </motion.h2>
        
        <motion.p 
          className="mb-6 text-gray-300 text-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          Tu pago ha sido procesado correctamente. Ya puedes acceder a tu eBook completo de 1/4 de milla.
        </motion.p>
        
        <motion.button
          onClick={onAccessEbook}
          className="w-full bg-race-red py-4 px-6 font-bebas neon-button flex items-center justify-center text-xl mb-4"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <BookOpen size={28} className="mr-3" />
          ACCEDER AL EBOOK COMPLETO
          <ExternalLink size={24} className="ml-3" />
        </motion.button>
        
        <motion.p 
          className="text-xs text-gray-500"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          Se abrirá en una nueva pestaña para que puedas leer o descargar el PDF completo.
        </motion.p>

        <motion.div
          className="absolute top-4 right-4 text-green-500"
          initial={{ opacity: 0, rotate: -90 }}
          animate={{ opacity: 1, rotate: 0 }}
          transition={{ delay: 0.7 }}
        >
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default PaymentSuccess;