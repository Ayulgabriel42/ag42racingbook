import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wrench, PlusCircle } from 'lucide-react';
import AnimatedSection from './AnimatedSection';

interface Component {
  id: string;
  name: string;
  description: string;
  importance: number;
  details?: string;
  specifications?: string[];
}

const carComponents: Component[] = [
  {
    id: 'suspension',
    name: 'Suspensión',
    description: 'La suspensión, para este ejemplo de auto y preparación, es la siguiente: Amortiguadores FIJOS y espirales a medida con configuración para 1/4 de milla - Compresión "blanda" / Expansión "dura" -',
    importance: 90
  },
  {
    id: 'tires',
    name: 'Neumático',
    description: 'Los neumáticos son del tipo Slick (Black) con compuesto super blando en media 14" de diametro y 8" de ancho con perfil bajo. Para ese ancho de cubierta se recomienda una llanta de 1" o 2" mas angosta para favorecer la tracción.',
    importance: 95,
    details: 'En drag racing, los neumáticos traseros (slicks) son completamente lisos para maximizar el área de contacto con la pista. Los delanteros son más angostos para reducir resistencia aerodinámica y peso no suspendido.',
    specifications: [
      '• Traseros: Slicks de 28-33" de diámetro',
      '• Delanteros: Neumáticos angostos 26-28"',
      '• Presión trasera: 8-12 PSI para máxima tracción',
      '• Presión delantera: 30-35 PSI para estabilidad',
      '• Compuesto blando para mejor agarre',
      '• Calentamiento previo obligatorio (burnout)'
    ]
  },
  {
    id: 'transmission',
    name: 'Transmisión',
    description: 'Una transmisión optimizada con tiempos de cambio rápidos y relaciones adecuadas maximiza la aceleración en cada tramo. En este caso se opto por adaptar una caja Lancia de Fiat Uno de 2 varillas con embrague de 3 pastillas. Para los cambios se opto por una 1era y 2da recta con relación mas larga y mejorar la transmisión de potencia al las ruedas en los primero metros.',
    importance: 85
  },
  {
    id: 'brakes',
    name: 'Frenos',
    description: 'Fundamentales para detener el vehículo con seguridad después de la carrera. Para este tipo de autos se suele adaptar frenos delanteros de Fiat Palio ya que son de mayor diámetro y ventilados de fabrica. No requiere muchas modificaciones y se logra cambios significativos.',
    importance: 75
  },
  {
    id: 'weight',
    name: 'Distribución de Peso',
    description: 'La correcta distribución del peso y la reducción del mismo mejoran significativamente la aceleración. El punto clave en la distribución de peso para esta configuración de autos es una relación de 70/30. En el eje delantero, donde esta la tracción en estos autos, debería tener mínimamente el 70% del peso del vehículo y en el eje trasero no mas del 30%.',
    importance: 88
  }
];

const Setup: React.FC = () => {
  const [activeComponent, setActiveComponent] = useState<string | null>(null);

  return (
    <AnimatedSection title="SETUP DEL VEHÍCULO" id="setup">
      <div className="mb-8 flex items-center justify-center">
        <Wrench size={28} className="text-race-red mr-2" />
        <h3 className="font-bebas text-2xl">DIAGRAMA INTERACTIVO</h3>
      </div>

      {/* Unified Component Selection with Car Image */}
      <div className="relative mb-12">
        <div 
          className="relative w-full h-48 md:h-64 bg-race-gray rounded-lg overflow-hidden"
          style={{
            backgroundImage: `url('/501077354_23964464043149979_8531575670483445466_n copy.jpg')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
        >
          {/* Darker overlay with more transparency for banner effect */}
          <div className="absolute inset-0 bg-black/70 rounded-lg"></div>
          
          {/* Car info - Bottom left */}
          <div className="absolute bottom-4 left-4 z-10">
            <h4 className="font-bebas text-lg md:text-xl text-race-red mb-1">FIAT VIVACE 1.6L ASPIRADO - CAT. 6 402mts</h4>
            <p className="text-sm text-gray-300">
              Ejemplo de preparación completa para 1/4 de milla
            </p>
          </div>
          
          {/* Instructions - Bottom right */}
          <div className="absolute bottom-4 right-4 z-10">
            <div className="bg-black/70 border border-race-red/50 rounded px-2 py-1 backdrop-blur-sm">
              <p className="text-[10px] text-gray-300 text-right leading-tight">
                💡 Haz clic en cualquier componente<br/>para ver información detallada
              </p>
            </div>
          </div>

          {/* Component Selection Buttons - Overlaid on image */}
          <div className="absolute top-4 left-4 right-4 z-10">
            <div className="space-y-4">
              {/* Primera fila - 3 botones */}
              <div className="grid grid-cols-3 gap-2">
                {carComponents.slice(0, 3).map((component) => (
                  <motion.button
                    key={component.id}
                    className={`p-3 rounded-lg font-bebas text-sm text-center transition-all border ${
                      activeComponent === component.id 
                        ? 'bg-race-red text-white border-race-red neon-border' 
                        : 'bg-black/60 hover:bg-black/80 border-gray-600 hover:border-race-red text-white backdrop-blur-sm'
                    }`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setActiveComponent(component.id)}
                  >
                    <div className="text-sm leading-tight">{component.name}</div>
                  </motion.button>
                ))}
              </div>
              
              {/* Segunda fila - 2 botones centrados */}
              <div className="grid grid-cols-2 gap-2 max-w-md mx-auto mt-16">
                {carComponents.slice(3, 5).map((component) => (
                  <motion.button
                    key={component.id}
                    className={`p-3 rounded-lg font-bebas text-sm text-center transition-all border ${
                      activeComponent === component.id 
                        ? 'bg-race-red text-white border-race-red neon-border' 
                        : 'bg-black/60 hover:bg-black/80 border-gray-600 hover:border-race-red text-white backdrop-blur-sm'
                    }`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setActiveComponent(component.id)}
                  >
                    <div className="text-sm leading-tight">{component.name}</div>
                  </motion.button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Component details */}
      <motion.div 
        className="bg-race-gray rounded-lg p-6 border border-race-red"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeComponent ? (
          carComponents.filter(c => c.id === activeComponent).map(component => (
            <div key={component.id}>
              <h4 className="font-bebas text-2xl mb-3 text-race-red">{component.name}</h4>
              <p className="mb-4 text-lg">{component.description}</p>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span>Importancia en 1/4 de milla</span>
                  <span>{component.importance}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <motion.div 
                    className="bg-race-red h-2 rounded-full neon-border" 
                    initial={{ width: 0 }}
                    animate={{ width: `${component.importance}%` }}
                    transition={{ duration: 1, delay: 0.3 }}
                  ></motion.div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Wrench size={48} className="text-race-red mx-auto mb-4 animate-pulse" />
              <p className="font-bebas text-xl mb-2">Selecciona un componente para ver sus detalles</p>
              <p className="text-sm text-gray-400">
                Haz clic en cualquiera de los botones de arriba para conocer más sobre cada parte del vehículo
              </p>
            </motion.div>
          </div>
        )}
      </motion.div>

      {/* Additional info section */}
      <div className="mt-12 bg-race-gray/50 p-6 rounded-lg border border-race-red">
        <h4 className="font-bebas text-xl text-race-red mb-3">FILOSOFÍA DE SETUP AG-42</h4>
        <p className="text-lg leading-relaxed">
          En AG-42 Racing creemos que el setup exitoso de un vehículo para drag racing requiere 
          un enfoque holístico. No basta con agregar componentes de alto rendimiento; cada modificación 
          debe ser cuidadosamente integrada en un sistema coherente que maximice la potencia, 
          mantenga la confiabilidad y garantice la seguridad del piloto.
        </p>
      </div>
    </AnimatedSection>
  );
};

export default Setup;