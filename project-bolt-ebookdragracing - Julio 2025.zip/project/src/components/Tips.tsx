import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Lightbulb } from 'lucide-react';
import AnimatedSection from './AnimatedSection';

interface Tip {
  id: number;
  text: string;
  category: string;
}

const tipsList: Tip[] = [
  { 
    id: 1, 
    text: "Calentar los neumáticos antes de cada carrera para maximizar la tracción en la salida",
    category: "PREPARACIÓN"
  },
  { 
    id: 2, 
    text: "Verificar la presión de los neumáticos cuando estén fríos, nunca después de rodar",
    category: "TÉCNICO"
  },
  { 
    id: 3, 
    text: "Practicar el tiempo de reacción al semáforo regularmente - cada milésima cuenta",
    category: "CONDUCCIÓN"
  },
  { 
    id: 4, 
    text: "Mantener el vehículo en perfecto estado de mantenimiento para máximo rendimiento",
    category: "MANTENIMIENTO"
  },
  { 
    id: 5, 
    text: "Un buen sistema de refrigeración es vital para carreras consecutivas sin pérdida de potencia",
    category: "TÉCNICO"
  },
  { 
    id: 6, 
    text: "Conocer los límites de tu vehículo antes de exigirlo al máximo en competición",
    category: "SEGURIDAD"
  },
  { 
    id: 7, 
    text: "La técnica de lanzamiento es más importante que la potencia bruta del motor",
    category: "CONDUCCIÓN"
  },
  { 
    id: 8, 
    text: "Estudiar las condiciones de la pista: temperatura, humedad y adherencia",
    category: "ESTRATEGIA"
  }
];

const Tips: React.FC = () => {
  const [activeTip, setActiveTip] = useState<number>(1);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTip(prev => (prev < tipsList.length ? prev + 1 : 1));
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  const currentTip = tipsList.find(tip => tip.id === activeTip);

  return (
    <AnimatedSection title="CONSEJOS PROFESIONALES" id="tips">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-center">
        <div className="lg:col-span-2">
          <div className="flex items-center mb-4">
            <Lightbulb size={28} className="text-race-red mr-2" />
            <h3 className="font-bebas text-2xl">TIPS DE EXPERTOS</h3>
          </div>
          
          <div className="bg-race-gray/50 p-4 rounded-lg border-l-4 border-race-red mb-6">
            <div 
              className="relative p-6 rounded-lg border border-race-red mb-6 overflow-hidden"
              style={{
                backgroundImage: `url('/492343044_9884335161589437_7176982996699158342_n.jpg')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat'
              }}
            >
              {/* Dark overlay for better text readability */}
              <div className="absolute inset-0 bg-black/70 rounded-lg"></div>
              
              {/* Content positioned above the background image */}
              <div className="relative z-10">
                <h4 className="font-bebas text-lg text-race-red mb-2">SABIDURÍA DE PISTA</h4>
                <p className="text-sm">
                  Estos consejos han sido recopilados de pilotos profesionales, mecánicos especializados 
                  y preparadores con décadas de experiencia en drag racing. Cada tip puede marcar la 
                  diferencia entre una carrera promedio y un nuevo récord personal.
                </p>
              </div>
            </div>
              
            <p className="mb-4">
              El 1/4 de milla no es solo sobre potencia bruta. La preparación meticulosa, la técnica 
              de conducción y el conocimiento profundo de tu vehículo son igual de importantes que 
              los caballos de fuerza bajo el capó.
            </p>
            
            <p className="text-sm text-gray-400">
              <strong>Recuerda:</strong> La consistencia es clave. Practica regularmente y registra 
              tus tiempos para monitorear tu progreso. En el drag racing, cada milésima de segundo cuenta.
            </p>
          </div>
        </div>

        <div className="lg:col-span-3">
          <motion.div 
            className="bg-race-gray border border-race-red rounded-lg p-8 h-80 flex flex-col items-center justify-center neon-border relative overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            {/* Background pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="w-full h-full bg-gradient-to-br from-race-red to-transparent"></div>
            </div>
            
            {tipsList.map((tip) => (
              <motion.div
                key={tip.id}
                className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ 
                  opacity: tip.id === activeTip ? 1 : 0,
                  scale: tip.id === activeTip ? 1 : 0.8
                }}
                transition={{ duration: 0.5 }}
              >
                {tip.id === activeTip && currentTip && (
                  <>
                    <div className="mb-4">
                      <span className="inline-block bg-race-red text-white px-3 py-1 rounded-full text-xs font-bold mb-2">
                        {currentTip.category}
                      </span>
                      <div className="led-text text-2xl md:text-3xl text-race-red mb-4 animate-blink">
                        TIP #{tip.id}
                      </div>
                    </div>
                    <p className="font-roboto text-lg md:text-xl text-race-white leading-relaxed">
                      {tip.text}
                    </p>
                  </>
                )}
              </motion.div>
            ))}
          </motion.div>

          <div className="flex justify-center mt-6 space-x-2">
            {tipsList.map((tip) => (
              <button
                key={tip.id}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  tip.id === activeTip ? 'bg-race-red neon-border scale-125' : 'bg-gray-600 hover:bg-gray-500'
                }`}
                onClick={() => setActiveTip(tip.id)}
                aria-label={`Ver tip ${tip.id}`}
              />
            ))}
          </div>
          
          <div className="text-center mt-4">
            <p className="text-xs text-gray-500">
              Click en los puntos para navegar • Auto-avance cada 5 segundos
            </p>
          </div>
        </div>
      </div>
    </AnimatedSection>
  );
};

export default Tips;