import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Instagram, 
  Youtube, 
  Mail, 
  BookOpen,
  Eye,
  Download,
  CheckCircle,
  Star,
  Gift,
  MessageSquare,
  Facebook
} from 'lucide-react';
import AutoPaymentButton from './AutoPaymentButton';
import PaymentSuccess from './PaymentSuccess';
import ContactForm from './ContactForm';

const Footer: React.FC = () => {
  const [showPaymentSuccess, setShowPaymentSuccess] = useState(false);
  const [hasPaymentAccess, setHasPaymentAccess] = useState(false);

  // Check if user has already paid on component mount
  useEffect(() => {
    const checkPaymentStatus = () => {
      const paymentSuccess = localStorage.getItem('ebookPaymentSuccess');
      if (paymentSuccess === 'true') {
        console.log('✅ Usuario ya tiene acceso pagado');
        setHasPaymentAccess(true);
        return true;
      }

      // Check URL parameters for payment success
      const urlParams = new URLSearchParams(window.location.search);
      const paymentStatus = urlParams.get('payment');
      const status = urlParams.get('status');
      const paymentId = urlParams.get('payment_id');
      const collectionId = urlParams.get('collection_id');
      const preferenceId = urlParams.get('preference_id');
      const merchantOrderId = urlParams.get('merchant_order_id');
      
      console.log('🔍 Verificando parámetros de URL:', {
        payment: paymentStatus,
        status: status,
        payment_id: paymentId,
        collection_id: collectionId,
        preference_id: preferenceId,
        merchant_order_id: merchantOrderId
      });
      
      if (paymentStatus === 'approved' || 
          paymentStatus === 'success' || 
          status === 'success' || 
          status === 'approved' ||
          paymentId || 
          collectionId ||
          preferenceId ||
          merchantOrderId) {
        console.log('🎉 Pago detectado en URL - procesando...');
        handlePaymentSuccess();
        
        // Clean URL after showing success
        setTimeout(() => {
          const cleanUrl = window.location.origin + window.location.pathname;
          window.history.replaceState({}, document.title, cleanUrl);
        }, 3000);
        
        return true;
      }
      
      return false;
    };

    checkPaymentStatus();

    // Listen for storage changes (in case payment is completed in another tab)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'ebookPaymentSuccess' && e.newValue === 'true') {
        console.log('🔄 Pago detectado en otra pestaña');
        setHasPaymentAccess(true);
        setShowPaymentSuccess(true);
      }
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  // Handle payment success - show success modal
  const handlePaymentSuccess = () => {
    console.log('🎉 Payment success callback triggered');
    setHasPaymentAccess(true);
    setShowPaymentSuccess(true);
    
    // Store payment success
    localStorage.setItem('ebookPaymentSuccess', 'true');
    localStorage.setItem('ebookPaymentDate', new Date().toISOString());
    
    // Clear payment attempt flags
    localStorage.removeItem('paymentInitiated');
    localStorage.removeItem('paymentAttemptTime');
  };

  // Handle accessing the full eBook after payment
  const handleAccessEbook = () => {
    const googleDriveUrl = 'https://drive.google.com/file/d/1mLkgP2Rpl7ZsSYN4TPTyiI9sOR5Zul1V/view?usp=drive_link';
    console.log('📖 Abriendo eBook completo:', googleDriveUrl);
    window.open(googleDriveUrl, '_blank', 'noopener,noreferrer');
    setShowPaymentSuccess(false);
  };

  // Direct access for paid users
  const handleDirectAccess = () => {
    const googleDriveUrl = 'https://drive.google.com/file/d/1mLkgP2Rpl7ZsSYN4TPTyiI9sOR5Zul1V/view?usp=drive_link';
    console.log('📖 Acceso directo al eBook:', googleDriveUrl);
    window.open(googleDriveUrl, '_blank', 'noopener,noreferrer');
  };

  // Preview function - now checks if user has paid
  const handlePreview = () => {
    if (hasPaymentAccess) {
      // User has paid, give them full access
      handleDirectAccess();
    } else {
      // User hasn't paid, show preview message
      const previewModal = document.createElement('div');
      previewModal.innerHTML = `
        <div style="
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0,0,0,0.9);
          z-index: 9999;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        ">
          <div style="
            background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)), url('/E book 42.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            filter: brightness(1.2) contrast(1.1);
            color: white;
            padding: 30px;
            border-radius: 10px;
            border: 2px solid #FF0000;
            box-shadow: 0 0 20px #FF0000;
            max-width: 500px;
            text-align: center;
            font-family: 'Roboto', sans-serif;
          ">
            <div style="font-size: 48px; margin-bottom: 20px;">🏁</div>
            <h3 style="color: #FF0000; margin: 0 0 20px 0; font-size: 24px; font-family: 'Bebas Neue', sans-serif;">VISTA PREVIA DEL EBOOK</h3>
            <p style="margin: 0 0 20px 0; line-height: 1.6;">
              <strong>🏆 "402 METROS. UNA PASIÓN SIN LÍMITES"</strong>
              <br><br>
              Este eBook contiene <strong>20 páginas</strong> con:
              <br><br>
              🚗 <strong>Técnicas básicas de conducción</strong><br>
              🔧 <strong>Datos de Setup del vehículo</strong><br>
              🏁 <strong>Tips profesionales</strong><br>
              📚 <strong>Historia y evolución del 1/4 de milla</strong><br>
              ⚡ <strong>Datos objetivos para mejorar tus tiempos</strong><br>
              🛡️ <strong>Guía de elementos requeridos de seguridad</strong><br>
              <br>
              <span style="color: #FF0000; font-weight: bold;">💰 PRECIO FINAL: $7900 ARS</span>
              <br>
              <small style="color: #888;">Acceso inmediato después del pago</small>
            </p>
            <button onclick="this.parentElement.parentElement.remove()" style="
              background: #FF0000;
              color: white;
              border: none;
              padding: 12px 24px;
              border-radius: 5px;
              cursor: pointer;
              font-family: 'Bebas Neue', sans-serif;
              font-size: 16px;
              margin-right: 10px;
            ">CERRAR</button>
            <button onclick="document.getElementById('ebook-purchase').scrollIntoView(); this.parentElement.parentElement.remove();" style="
              background: #4CAF50;
              color: white;
              border: none;
              padding: 12px 24px;
              border-radius: 5px;
              cursor: pointer;
              font-family: 'Bebas Neue', sans-serif;
              font-size: 16px;
            ">COMPRAR AHORA</button>
          </div>
        </div>
      `;
      document.body.appendChild(previewModal);
    }
  };

  return (
    <>
      <footer id="footer" className="bg-race-gray py-16 mt-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {/* Contact & Social */}
            <div>
              <h3 className="font-bebas text-3xl mb-6 neon-text">CONTACTO</h3>
              <div className="flex space-x-4 mb-6">
                <motion.a 
                  href="https://www.facebook.com/brio442"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1 }}
                  className="bg-race-black p-2 rounded-full hover:neon-border"
                  aria-label="Facebook"
                >
                  <Facebook size={24} className="text-race-red" />
                </motion.a>
                <motion.a 
                  href="https://www.instagram.com/ag42racingbook/"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1 }}
                  className="bg-race-black p-2 rounded-full hover:neon-border"
                  aria-label="Instagram"
                >
                  <Instagram size={24} className="text-race-red" />
                </motion.a>
                <motion.a 
                  href="https://www.youtube.com/@ayulgabriel42"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1 }}
                  className="bg-race-black p-2 rounded-full hover:neon-border"
                  aria-label="YouTube"
                >
                  <Youtube size={24} className="text-race-red" />
                </motion.a>
              </div>
              <p className="mb-2">
                <Mail size={16} className="inline-block mr-2 text-race-red" />
                ayulgabriel@gmail.com
              </p>
              <motion.div 
                className="mt-4 p-3 bg-gradient-to-r from-orange-600/10 to-red-600/10 rounded border border-orange-500/50 relative overflow-hidden"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
              >
                {/* Animated background effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-orange-500/3 to-red-500/3"></div>
                
                <div className="relative z-10 text-center">
                  <div className="flex items-center justify-center mb-1">
                    <span className="text-sm mr-1">🏁</span>
                    <span className="font-bebas text-sm text-orange-400 tracking-wide">
                      ELEMENTOS DE COMPETICIÓN
                    </span>
                    <span className="text-sm ml-1">🔧</span>
                  </div>
                  
                  <motion.p 
                    className="text-white font-medium text-xs"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    Conocé nuestros insumos <span className="text-orange-400 font-bold">RACING</span>
                  </motion.p>
                  
                  <div className="flex items-center justify-center mt-1 space-x-2 text-[10px]">
                    <span className="text-orange-300">⚡</span>
                    <span className="text-gray-300">Calidad profesional</span>
                    <span className="text-orange-300">•</span>
                    <span className="text-gray-300">Máximo rendimiento</span>
                    <span className="text-orange-300">⚡</span>
                  </div>
                </div>
              </motion.div>
              
              {/* Logo AG-42 Racing Parts */}
              <div className="mt-4 flex justify-center">
                <motion.a
                  href="https://www.instagram.com/ag42.racing.parts"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95, rotate: 2 }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.img
                    src="/1000000025 copy.jpg"
                    alt="AG-42 Racing Parts Logo - Visita nuestro Instagram"
                    className="max-w-full h-auto max-h-24 md:max-h-32 object-contain rounded-lg cursor-pointer hover:shadow-lg transition-all duration-300"
                    whileHover={{ 
                      scale: 1.02,
                      boxShadow: "0 0 20px rgba(255, 165, 0, 0.6)",
                      filter: "brightness(1.1)"
                    }}
                    whileTap={{ 
                      scale: 0.98,
                      rotate: -1,
                      transition: { duration: 0.1 }
                    }}
                  />
                </motion.a>
              </div>
              
              {/* Instagram link text */}
              <div className="mt-2 text-center">
                <motion.a
                  href="https://www.instagram.com/ag42.racing.parts"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-sm text-gray-400 hover:text-orange-400 transition-colors duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Instagram size={16} className="mr-1" />
                  @ag42.racing.parts
                </motion.a>
              </div>
            </div>

            {/* Formulario de Consultas */}
            <div>
              <div className="flex items-center mb-6">
                <h3 className="font-bebas text-3xl neon-text">CONSULTAS</h3>
                <MessageSquare size={28} className="text-race-red ml-2" />
              </div>
              <ContactForm />
            </div>

            {/* eBook buttons */}
            <div id="ebook-purchase">
              <div className="flex items-center mb-6">
                <h3 className="font-bebas text-3xl neon-text">OBTÉN EL EBOOK</h3>
                <Gift size={28} className="text-yellow-500 ml-2 animate-bounce" />
              </div>
              
              <div className="space-y-4">
                {/* Show different content based on payment status */}
                {hasPaymentAccess ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-center bg-green-900/30 border border-green-500 rounded-lg p-3 mb-4">
                      <CheckCircle className="text-green-500 mr-2" size={20} />
                      <span className="text-green-500 font-bebas">¡PAGO CONFIRMADO!</span>
                    </div>
                    
                    <motion.button
                      onClick={handleDirectAccess}
                      className="flex items-center justify-center bg-green-600 hover:bg-green-700 py-4 px-6 font-bebas neon-button w-full text-xl transition-all"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Download size={24} className="mr-3" />
                      ACCEDER AL EBOOK COMPLETO
                    </motion.button>
                    
                    <motion.button
                      onClick={handleDirectAccess}
                      className="flex items-center justify-center bg-race-red py-3 px-6 font-bebas neon-button w-full"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <BookOpen size={20} className="mr-2" />
                      LEER AHORA
                    </motion.button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Botón de pago automático */}
                    <AutoPaymentButton onPaymentSuccess={handlePaymentSuccess} />
                  </div>
                )}
                
                <motion.button
                  onClick={handlePreview}
                  className={`flex items-center justify-center py-3 px-6 font-bebas w-full transition-all ${
                    hasPaymentAccess 
                      ? 'bg-race-black border border-race-red hover:neon-border' 
                      : 'bg-race-black border border-race-red hover:neon-border'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Eye size={20} className="mr-2" />
                  {hasPaymentAccess ? 'INFORMACIÓN DEL EBOOK' : 'VISTA PREVIA GRATUITA'}
                </motion.button>
                
                <div className="text-center">
                  <p className="text-sm text-gray-400 mb-2">
                    {hasPaymentAccess 
                      ? '¡Gracias por tu compra! Ya tienes acceso completo al eBook.'
                      : ''
                    }
                  </p>
                  {!hasPaymentAccess && (
                    <div className="space-y-1">
                      <p className="text-xs text-purple-400">
                        🎯 20 páginas de contenido exclusivo
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-16 pt-8 border-t border-gray-800 text-center text-sm text-gray-500">
            <p>© {new Date().getFullYear()} AG-42 Racing Parts. Todos los derechos reservados.</p>
            <div className="mt-2 space-x-4">
              <a href="#" className="hover:text-race-red transition-colors">Términos y Condiciones</a>
              <a href="#" className="hover:text-race-red transition-colors">Política de Privacidad</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Payment Success Modal */}
      <PaymentSuccess
        isVisible={showPaymentSuccess}
        onAccessEbook={handleAccessEbook}
      />
    </>
  );
};

export default Footer;