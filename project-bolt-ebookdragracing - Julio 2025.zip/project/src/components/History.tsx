import React from 'react';
import { motion } from 'framer-motion';
import { History as HistoryIcon } from 'lucide-react';
import AnimatedSection from './AnimatedSection';

interface TimelineEvent {
  year: string;
  title: string;
  description: string;
  details: string;
}

const timelineEvents: TimelineEvent[] = [
  {
    year: '1950s',
    title: 'Los Orígenes',
    description: 'Nacimiento del drag racing organizado en Estados Unidos como alternativa a las carreras callejeras.',
    details: 'Las primeras pistas oficiales se construyeron en California, estableciendo las bases del deporte moderno.'
  },
  {
    year: '1970s-80s',
    title: 'Profesionalización',
    description: 'Se establecen categorías oficiales y reglamentos estandarizados internacionalmente.',
    details: 'Nacen las categorías Pro Stock, Top Fuel y Funny Car que conocemos hoy en día.'
  },
  {
    year: '1990s',
    title: 'Auge de la actividad en nuestro pais',
    description: 'Durante esta decada, se empieza a notar un gran fenomeno dentro del ambito automovilistico, crece con fuerza el desarrolo de los autos de 1/4 de milla.',
    details: 'Las organizaciones se vuelven mas estructuradas, las preparaciones de los autos comienzan a implementar los nuevos avances electronicos de la epoca y los pilotos ya se dedican exclusivamente a esta actividad.'
  },
  {
    year: 'HOY',
    title: 'De Argentina para el mundo',
    description: 'Hoy podemos decir que los autos de 1/4 de milla nacionales estan al nivel de los grandes paises que desarrollan la actividad.',
    details: `Como claro ejemplo de esto, tenemos a Alejanrdo "Pajaro" Lucas - Gol trend turbo 4WD / Team Mirabelli - que este año logro coronarse campeon del evento mas grande de 1/8 de milla -NO PREP- sudamericano realizado en Brasil - Armageddon 2025.`
  }
];

const History: React.FC = () => {
  return (
    <AnimatedSection title="HISTORIA Y EVOLUCIÓN DEL DRAG RACING" id="history">
      <div className="mb-8">
        <div className="flex items-center justify-center mb-6">
          <HistoryIcon size={28} className="text-race-red mr-2" />
          <h3 className="font-bebas text-2xl">TIMELINE INTERACTIVO</h3>
        </div>
        
        <div className="bg-race-gray/50 p-6 rounded-lg border border-race-red mb-8">
          <h4 className="font-bebas text-xl text-race-red mb-3">EL NACIMIENTO DE UNA PASIÓN</h4>
          <p className="text-lg leading-relaxed">
            El drag racing nació de la necesidad de crear un espacio seguro y controlado para las competiciones 
            de aceleración. Lo que comenzó como carreras informales en las calles de California se transformó 
            en uno de los deportes automovilísticos más emocionantes y técnicamente avanzados del mundo.
          </p>
        </div>
      </div>

      <div className="relative">
        {/* Timeline center line */}
        <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-race-red neon-border"></div>

        {timelineEvents.map((event, index) => (
          <motion.div 
            key={index}
            className={`flex items-center mb-16 ${
              index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
            } relative`}
            initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true, amount: 0.5 }}
          >
            {/* Year indicator */}
            <div className={`w-1/2 ${index % 2 === 0 ? 'text-right pr-8' : 'text-left pl-8'}`}>
              <span className="font-bebas text-4xl text-race-red neon-text">{event.year}</span>
            </div>

            {/* Timeline node */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-8 h-8 bg-race-red rounded-full border-4 border-black z-10 neon-border"></div>

            {/* Content */}
            <div className={`w-1/2 ${index % 2 === 0 ? 'text-left pl-8' : 'text-right pr-8'}`}>
              <motion.div 
                className="bg-race-gray p-6 rounded-lg border border-race-red hover:neon-border transition-all duration-300"
                whileHover={{ scale: 1.03 }}
              >
                <h4 className="font-bebas text-2xl text-race-red mb-3">{event.title}</h4>
                <p className="text-base mb-3 font-medium">{event.description}</p>
                <p className="text-sm text-gray-300 italic">{event.details}</p>
              </motion.div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-12 bg-race-gray/50 p-6 rounded-lg border border-race-red">
        <div 
          className="mt-12 p-6 rounded-lg border border-race-red relative overflow-hidden"
          style={{
            backgroundImage: `url('/9 (1) copy.jpg')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
        >
          {/* Dark overlay for better text readability */}
          <div className="absolute inset-0 bg-black/65 rounded-lg"></div>
          
          {/* Content with relative positioning to appear above overlay */}
          <div className="relative z-10">
            <h4 className="font-bebas text-xl text-race-red mb-3">EL DRAG RACING EN ARGENTINA</h4>
            <p className="text-lg leading-relaxed">
              En Argentina, el drag racing ha experimentado un crecimiento constante desde los años 90. 
              Autódromos como el de Buenos Aires y circuitos especializados han sido testigos de 
              increíbles performances de pilotos locales que compiten con vehículos preparados 
              específicamente para esta disciplina, desde autos totalmente originales hasta los desarrollos mas avanzados a nivel mundial. 
            </p>
          </div>
        </div>

        {/* Dato Curioso - Récord Mundial */}
        <motion.div 
          className="mt-8 bg-gradient-to-r from-yellow-900/20 to-orange-900/20 p-4 rounded-lg border border-yellow-500 relative overflow-hidden"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <div className="bg-yellow-500 text-black px-2 py-1 rounded-full text-xs font-bold mr-2">
                  DATO CURIOSO
                </div>
                <span className="text-lg">🏆</span>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
              <div className="flex-1">
                <h4 className="font-bebas text-lg md:text-xl text-yellow-400 mb-2">
                  ¿SABÍAS QUE ARGENTINA TIENE EL RÉCORD FWD STOCK CHASIS MUNDIAL?
                </h4>
                <p className="text-sm text-gray-300">
                  El Team VITURRO ostenta uno de los records más importantes de 1/4 de milla a nivel mundial.
                </p>
              </div>
              
              <motion.a
                href="https://www.youtube.com/watch?v=AYANNsrABsI"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center bg-red-600 hover:bg-red-700 text-white font-bebas text-sm px-4 py-2 rounded transition-all duration-300 hover:scale-105 flex-shrink-0"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <svg 
                  className="w-4 h-4 mr-2" 
                  fill="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                </svg>
                VER RÉCORD
                <svg 
                  className="w-3 h-3 ml-1" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
              </motion.a>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatedSection>
  );
};

export default History;