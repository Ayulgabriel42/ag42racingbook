import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Timer } from 'lucide-react';
import AnimatedSection from './AnimatedSection';

const QuarterMile: React.FC = () => {
  const [time, setTime] = useState('00.000');
  const [gameState, setGameState] = useState<'idle' | 'ready' | 'yellow1' | 'yellow2' | 'yellow3' | 'running' | 'finished'>('idle');
  const [startTime, setStartTime] = useState<number>(0);
  const [reactionTime, setReactionTime] = useState<number | null>(null);
  const [bestTime, setBestTime] = useState<number | null>(null);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    if (gameState === 'ready') {
      timeout = setTimeout(() => {
        setGameState('yellow1');
      }, 1000);
    } else if (gameState === 'yellow1') {
      timeout = setTimeout(() => {
        setGameState('yellow2');
      }, 500);
    } else if (gameState === 'yellow2') {
      timeout = setTimeout(() => {
        setGameState('yellow3');
      }, 500);
    } else if (gameState === 'yellow3') {
      const delay = 500;
      timeout = setTimeout(() => {
        setGameState('running');
        setStartTime(Date.now());
      }, delay);
    }

    return () => {
      if (timeout) clearTimeout(timeout);
    };
  }, [gameState]);

  const handleClick = () => {
    switch (gameState) {
      case 'idle':
        setGameState('ready');
        setReactionTime(null);
        setTime('00.000');
        break;
      
      case 'ready':
      case 'yellow1':
      case 'yellow2':
      case 'yellow3':
        setGameState('finished');
        setReactionTime(-1);
        break;
      
      case 'running':
        const endTime = Date.now();
        const reaction = (endTime - startTime) / 1000;
        setReactionTime(reaction);
        
        if (bestTime === null || reaction < bestTime) {
          setBestTime(reaction);
        }
        
        setTime(reaction.toFixed(3).padStart(6, '0'));
        setGameState('finished');
        break;
      
      case 'finished':
        setGameState('idle');
        break;
    }
  };

  const getLightColors = () => {
    const lights = ['bg-gray-800', 'bg-gray-800', 'bg-gray-800', 'bg-gray-800', 'bg-gray-800'];
    
    switch (gameState) {
      case 'ready':
        lights[0] = 'bg-red-600';
        break;
      case 'yellow1':
        lights[0] = 'bg-red-600';
        lights[1] = 'bg-yellow-500';
        break;
      case 'yellow2':
        lights[0] = 'bg-red-600';
        lights[1] = 'bg-yellow-500';
        lights[2] = 'bg-yellow-500';
        break;
      case 'yellow3':
        lights[0] = 'bg-red-600';
        lights[1] = 'bg-yellow-500';
        lights[2] = 'bg-yellow-500';
        lights[3] = 'bg-yellow-500';
        break;
      case 'running':
        lights[4] = 'bg-green-500';
        break;
    }
    
    return lights;
  };

  const getMessage = () => {
    switch (gameState) {
      case 'idle':
        return 'Click para comenzar';
      case 'ready':
      case 'yellow1':
      case 'yellow2':
      case 'yellow3':
        return '¡Espera la luz verde!';
      case 'running':
        return '¡AHORA!';
      case 'finished':
        return reactionTime === -1 
          ? '¡Falsa largada! Click para reintentar' 
          : 'Click para intentar de nuevo';
    }
  };

  return (
    <AnimatedSection title="¿QUÉ ES EL 1/4 DE MILLA?" id="quarter-mile">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <p className="text-lg leading-relaxed">
            El cuarto de milla, también conocido como <strong>drag racing</strong>, es una modalidad de competición 
            automovilística donde dos vehículos compiten en línea recta por una distancia de exactamente 
            <strong className="text-race-red"> 402.336 metros</strong> (1/4 de milla).
          </p>
          
          <p className="text-lg leading-relaxed">
            Esta disciplina nació en Estados Unidos en la década de 1950 como una alternativa segura y 
            controlada a las carreras callejeras ilegales. Hoy en día, es una de las formas más populares 
            de automovilismo deportivo en el mundo.
          </p>
          
          <p className="text-lg leading-relaxed">
            En este eBook aprenderás todo sobre la base de esta fascinante disciplina: Un resumen desde la historia y evolución 
            del deporte hasta las técnicas más avanzadas de preparación y conducción que utilizan los 
            profesionales para alcanzar tiempos récord.
          </p>
        </div>

        <motion.div 
          className="bg-race-gray p-8 rounded-lg border border-race-red neon-border"
          whileHover={{ scale: 1.02 }}
        >
          <div className="flex items-center justify-center mb-6">
            <Timer size={32} className="text-race-red mr-3" />
            <h3 className="font-bebas text-3xl">SIMULADOR DE REACCIÓN</h3>
          </div>

          {/* Traffic lights */}
          <div className="flex justify-center space-x-4 mb-8">
            {getLightColors().map((color, index) => (
              <motion.div
                key={index}
                className={`w-16 h-16 rounded-full ${color} border-2 border-gray-600`}
                animate={{ 
                  scale: color.includes('red-600') || color.includes('yellow-500') || color.includes('green-500') ? [1, 1.1, 1] : 1,
                  boxShadow: color.includes('red-600') 
                    ? '0 0 20px #FF0000' 
                    : color.includes('yellow-500')
                    ? '0 0 20px #FFC107'
                    : color.includes('green-500') 
                      ? '0 0 20px #4CAF50'
                      : 'none'
                }}
                transition={{ duration: 0.3, repeat: Infinity }}
              />
            ))}
          </div>

          <div 
            onClick={handleClick}
            className="led-text text-6xl md:text-7xl font-mono bg-black p-8 rounded border border-race-red flex justify-center items-center h-32 cursor-pointer mb-6"
          >
            <span className={`text-race-red ${gameState === 'running' ? 'animate-blink' : ''}`}>
              {reactionTime === -1 ? '---.---' : time}
            </span>
          </div>
          
          <div className="text-center space-y-2">
            <p className="text-lg font-medium">{getMessage()}</p>
            {bestTime !== null && (
              <p className="text-sm text-race-red">
                Mejor tiempo: {bestTime.toFixed(3)}s
              </p>
            )}
            <p className="text-xs text-gray-400">
              Un buen tiempo de reacción profesional está entre 0.100-0.300 segundos
            </p>
            <p className="text-xs text-race-red mt-2 font-medium">
              Compartí en tus redes el mejor tiempo de reacción y etiquétanos: @ag42racingbook
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatedSection>
  );
};

export default QuarterMile;