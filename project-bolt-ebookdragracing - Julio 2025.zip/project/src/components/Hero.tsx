import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div 
      className="min-h-screen flex flex-col justify-center items-center relative bg-cover bg-center bg-fixed overflow-hidden"
      id="hero"
      style={{
        backgroundImage: `linear-gradient(to bottom, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url('/493940613_9884339764922310_2192753154034981357_n copy copy copy.jpg')`
      }}
    >
      {/* Content - Título principal más arriba */}
      <div className="container mx-auto px-4 z-10 text-center flex-1 flex flex-col justify-center pt-20 md:pt-24 lg:pt-20 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-12 mt-12 md:mt-16 lg:mt-20"
        >
          {/* Main Title - Posicionado más arriba */}
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="hero-title-container"
          >
            <h1 className="hero-main-title font-bebas text-5xl md:text-7xl lg:text-8xl xl:text-9xl mb-12 neon-text tracking-wide leading-tight">
              1/4 DE MILLA
              <br />
              <span className="text-race-red">UNA PASIÓN SIN LÍMITES</span>
            </h1>
          </motion.div>
          
          {/* Subtitle - Separado del título principal */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-16"
          >
            <p className="font-roboto text-lg md:text-xl lg:text-2xl mb-8 text-race-white/80 max-w-4xl mx-auto leading-relaxed">
              La <span className="text-race-red font-bold">PRIMERA</span> guía instructiva del 1/4 de milla argentino. Para poder conocer el arte del drag racing nacional: desde los fundamentos básicos hasta las técnicas que nadie te cuenta, de una manera sencilla y dinámica.
            </p>
            
            <h2 className="font-roboto text-xl md:text-2xl lg:text-3xl mb-8 text-race-white/90 mt-8">
              Por <span className="text-race-red font-bold">Gabriel y Gustavo Ayul</span> – AG-42 RACING BOOK
            </h2>
          </motion.div>
          
          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12"
          >
            <motion.a
              href="#ebook-purchase"
              className="bg-race-red text-race-white font-bebas text-xl md:text-2xl px-8 md:px-10 py-4 md:py-5 border border-white neon-button"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              DESCARGAR LA GUÍA
            </motion.a>
            
            <motion.a
              href="#quarter-mile"
              className="bg-transparent text-race-white font-bebas text-xl md:text-2xl px-8 md:px-10 py-4 md:py-5 border border-race-red hover:bg-race-red transition-colors duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              EXPLORAR CONTENIDO
            </motion.a>
          </motion.div>
          
          {/* Feature Cards */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 1.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto"
          >
            <div className="bg-black/60 p-6 md:p-8 rounded-lg border border-race-red/30 backdrop-blur-sm">
              <div className="text-race-red font-bebas text-2xl md:text-3xl mb-2">20 PÁGINAS</div>
              <div className="text-gray-300 text-base md:text-lg">Contenido especializado en Drag Racing</div>
            </div>
            <div className="bg-black/60 p-6 md:p-8 rounded-lg border border-race-red/30 backdrop-blur-sm">
              <div className="text-race-red font-bebas text-2xl md:text-3xl mb-2">EXPERIENCIA REAL</div>
              <div className="text-gray-300 text-base md:text-lg">Basado en años de competición</div>
            </div>
            <div className="bg-black/60 p-6 md:p-8 rounded-lg border border-race-red/30 backdrop-blur-sm">
              <div className="text-race-red font-bebas text-2xl md:text-3xl mb-2">TÉCNICAS PRO</div>
              <div className="text-gray-300 text-base md:text-lg">Secretos de pilotos profesionales</div>
            </div>
          </motion.div>
        </motion.div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1.5 }}
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <ChevronDown size={36} className="text-race-white/80" />
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Hero;