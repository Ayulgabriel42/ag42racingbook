import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, Loader2, AlertCircle, CheckCircle, Star } from 'lucide-react';

interface AutoPaymentButtonProps {
  onPaymentSuccess?: () => void;
}

const AutoPaymentButton: React.FC<AutoPaymentButtonProps> = ({ onPaymentSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Verificar si ya hay un pago exitoso guardado
    const savedPaymentSuccess = localStorage.getItem('ebookPaymentSuccess');
    if (savedPaymentSuccess === 'true') {
      setPaymentStatus('success');
      return;
    }

    // Detectar cuando el usuario regresa después del pago
    const handlePaymentReturn = () => {
      const urlParams = new URLSearchParams(window.location.search);
      
      console.log('🔍 Verificando parámetros de URL:', Object.fromEntries(urlParams.entries()));
      
      // Parámetros que indican pago exitoso
      const paymentSuccess = 
        urlParams.get('payment') === 'success' ||
        urlParams.get('payment') === 'approved' ||
        urlParams.get('status') === 'success' ||
        urlParams.get('status') === 'approved' ||
        urlParams.get('collection_status') === 'approved' ||
        urlParams.get('payment_id') ||
        urlParams.get('collection_id') ||
        urlParams.get('preference_id') ||
        urlParams.get('merchant_order_id');
      
      // Parámetros que indican pago pendiente (también lo consideramos exitoso)
      const paymentPending = 
        urlParams.get('payment') === 'pending' ||
        urlParams.get('status') === 'pending';
      
      // Parámetros que indican pago fallido
      const paymentFailure = 
        urlParams.get('payment') === 'failure' ||
        urlParams.get('status') === 'failure' ||
        urlParams.get('status') === 'rejected';

      if (paymentSuccess || paymentPending) {
        console.log('✅ Pago detectado como exitoso');
        setPaymentStatus('success');
        localStorage.setItem('ebookPaymentSuccess', 'true');
        localStorage.setItem('ebookPaymentDate', new Date().toISOString());
        
        if (onPaymentSuccess) {
          onPaymentSuccess();
        }

        // Limpiar URL después de un delay
        setTimeout(() => {
          const cleanUrl = window.location.origin + window.location.pathname;
          window.history.replaceState({}, document.title, cleanUrl);
        }, 2000);
        
      } else if (paymentFailure) {
        console.log('❌ Pago detectado como fallido');
        setPaymentStatus('error');
        setError('El pago no pudo ser procesado. Intenta nuevamente.');
        
        // Limpiar URL
        setTimeout(() => {
          const cleanUrl = window.location.origin + window.location.pathname;
          window.history.replaceState({}, document.title, cleanUrl);
        }, 3000);
      }
    };

    // Verificar inmediatamente al cargar
    handlePaymentReturn();

    // Escuchar cambios en la ventana
    const handleFocus = () => {
      console.log('🔄 Window focused - checking payment status');
      handlePaymentReturn();
    };

    window.addEventListener('focus', handleFocus);

    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, [onPaymentSuccess]);

  const handlePayment = async () => {
    console.log('🚀 Iniciando proceso de pago automático...');
    setLoading(true);
    setError(null);
    setPaymentStatus('processing');

    try {
      // Datos del producto con precio de $1 para pruebas
      const paymentData = {
        title: 'eBook: 402 Metros. Una Pasión. Un Estilo de Vida.',
        price: 7900 // Precio final: $7900 ARS
      };

      console.log('📤 Enviando datos a la función serverless:', paymentData);

      // Llamar a la función serverless para crear la preferencia
      const response = await fetch('/.netlify/functions/crearPago', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(paymentData)
      });

      console.log('📥 Respuesta del servidor:', response.status, response.statusText);

      if (!response.ok) {
        const errorData = await response.text();
        console.error('❌ Error del servidor:', errorData);
        throw new Error(`Error del servidor: ${response.status} - ${errorData}`);
      }

      const data = await response.json();
      console.log('✅ Preferencia creada:', data);

      if (!data.success || !data.init_point) {
        throw new Error('No se recibió el link de pago válido');
      }

      // Guardar que se inició el pago
      localStorage.setItem('paymentInitiated', 'true');
      localStorage.setItem('paymentAttemptTime', Date.now().toString());
      
      console.log('🔗 Redirigiendo a MercadoPago:', data.init_point);
      
      // Redirigir a MercadoPago
      window.location.href = data.init_point;

    } catch (err) {
      console.error('❌ Error al crear el pago:', err);
      const errorMessage = err instanceof Error ? err.message : 'Error desconocido al crear el pago';
      setError(errorMessage);
      setPaymentStatus('error');
      setLoading(false);
    }
  };

  // Botón de prueba para simular pago exitoso (solo en desarrollo)
  const handleTestPayment = () => {
    console.log('🧪 Simulando pago exitoso para pruebas');
    setPaymentStatus('success');
    localStorage.setItem('ebookPaymentSuccess', 'true');
    localStorage.setItem('ebookPaymentDate', new Date().toISOString());
    
    if (onPaymentSuccess) {
      onPaymentSuccess();
    }
  };

  // Verificar si el usuario había iniciado un pago anteriormente
  useEffect(() => {
    const paymentInitiated = localStorage.getItem('paymentInitiated');
    const paymentAttemptTime = localStorage.getItem('paymentAttemptTime');
    
    if (paymentInitiated === 'true' && paymentAttemptTime) {
      const attemptTime = parseInt(paymentAttemptTime);
      const now = Date.now();
      const timeDiff = now - attemptTime;
      
      // Si han pasado menos de 10 minutos desde el intento, mostrar estado de procesando
      if (timeDiff < 10 * 60 * 1000 && paymentStatus === 'idle') {
        console.log('🔄 Detectado intento de pago reciente, verificando estado...');
        setPaymentStatus('processing');
        
        // Limpiar después de un tiempo si no se detecta pago
        setTimeout(() => {
          if (paymentStatus === 'processing') {
            localStorage.removeItem('paymentInitiated');
            localStorage.removeItem('paymentAttemptTime');
            setPaymentStatus('idle');
          }
        }, 30000);
      }
    }
  }, []);

  const getButtonContent = () => {
    switch (paymentStatus) {
      case 'processing':
        return (
          <>
            <Loader2 size={24} className="animate-spin" />
            <span>CREANDO PAGO...</span>
          </>
        );
      case 'success':
        return (
          <>
            <CheckCircle size={24} />
            <span>¡PAGO EXITOSO!</span>
          </>
        );
      case 'error':
        return (
          <>
            <AlertCircle size={24} />
            <span>REINTENTAR PAGO</span>
          </>
        );
      default:
        return (
          <>
            <CreditCard size={24} />
            <span>💳 COMPRAR EBOOK - $7900 ARS</span>
          </>
        );
    }
  };

  const getButtonColor = () => {
    switch (paymentStatus) {
      case 'success':
        return 'from-green-600 to-green-700 hover:from-green-700 hover:to-green-800';
      case 'error':
        return 'from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800';
      case 'processing':
        return 'from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800';
      default:
        return 'from-race-red to-red-600 hover:from-red-600 hover:to-race-red';
    }
  };

  // Detectar si estamos en desarrollo
  const isDevelopment = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

  return (
    <div className="w-full">
      {/* Oferta especial badge */}
      <div className="relative mb-3">
        <motion.div 
          className="absolute -top-2 -right-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-3 py-1 rounded-full text-xs font-bold z-10 flex items-center shadow-lg"
          animate={{ 
            y: [0, -3, 0],
            scale: [1, 1.05, 1]
          }}
          transition={{ 
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <Star size={12} className="mr-1" />
          ¡PRECIO LANZAMIENTO!
        </motion.div>
        
        <motion.button
          onClick={handlePayment}
          disabled={loading || paymentStatus === 'success'}
          className={`relative w-full bg-gradient-to-r ${getButtonColor()} text-white font-bebas text-lg py-4 px-6 rounded-lg transition-all duration-500 transform hover:scale-105 flex items-center justify-center space-x-3 neon-button overflow-hidden group ${
            loading || paymentStatus === 'success' ? 'opacity-75 cursor-not-allowed' : ''
          }`}
          style={{
            minHeight: '56px',
            boxShadow: '0 4px 15px rgba(255, 0, 0, 0.3), 0 0 0 0 rgba(255, 0, 0, 0.4)',
            border: '2px solid #FF0000'
          }}
          whileTap={!loading && paymentStatus !== 'success' ? { scale: 0.98 } : {}}
          animate={{
            boxShadow: [
              '0 4px 15px rgba(255, 0, 0, 0.3), 0 0 0 0 rgba(255, 0, 0, 0.4)',
              '0 8px 25px rgba(255, 0, 0, 0.6), 0 0 30px 10px rgba(255, 0, 0, 0.3)',
              '0 4px 15px rgba(255, 0, 0, 0.3), 0 0 0 0 rgba(255, 0, 0, 0.4)'
            ]
          }}
          transition={{ 
            duration: 0.3,
            boxShadow: { 
              duration: 0.8,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut"
            }
          }}
        >
          {/* Efecto de resplandor del fondo que se activa en hover */}
          <div className="absolute inset-0 bg-gradient-to-r from-red-500/0 via-red-400/0 to-red-500/0 group-hover:from-red-500/20 group-hover:via-red-400/30 group-hover:to-red-500/20 transition-all duration-500 rounded-lg blur-sm"></div>
          
          {/* Efecto de pulso de fondo en hover */}
          <div className="absolute inset-0 bg-red-500/0 group-hover:bg-red-500/10 transition-all duration-300 rounded-lg"></div>
          
          {/* Efecto de brillo sutil que se mueve */}
          {paymentStatus === 'idle' && (
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent z-10"
              initial={{ x: '-100%', skewX: -12 }}
              animate={{ x: '200%' }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          )}
          
          {/* Contenido del botón con z-index mayor */}
          <div className="relative z-20 flex items-center space-x-3">
            {getButtonContent()}
          </div>
        </motion.button>
      </div>

      {/* Botón de prueba solo en desarrollo */}
      {isDevelopment && paymentStatus === 'idle' && (
        <motion.button
          onClick={handleTestPayment}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bebas text-sm py-2 px-4 rounded mb-3"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          🧪 SIMULAR PAGO EXITOSO (SOLO PRUEBAS)
        </motion.button>
      )}

      {/* Estado del pago */}
      {paymentStatus === 'processing' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-3 p-3 bg-blue-900/30 border border-blue-500 rounded-lg text-center"
        >
          <p className="text-blue-300 text-sm">
            🔄 Creando preferencia de pago...
          </p>
          <p className="text-xs text-blue-400 mt-1">
            Serás redirigido a MercadoPago en unos segundos
          </p>
          <button
            onClick={() => {
              localStorage.removeItem('paymentInitiated');
              localStorage.removeItem('paymentAttemptTime');
              setPaymentStatus('idle');
              setError(null);
            }}
            className="text-xs text-blue-300 underline mt-2 hover:text-blue-200"
          >
            Cancelar
          </button>
        </motion.div>
      )}

      {paymentStatus === 'success' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-3 p-3 bg-green-900/30 border border-green-500 rounded-lg text-center"
        >
          <p className="text-green-300 text-sm">
            ✅ ¡Pago confirmado! Ya tienes acceso al eBook completo.
          </p>
        </motion.div>
      )}

      {error && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-3 p-3 bg-red-900/30 border border-red-500 rounded-lg text-sm"
        >
          <div className="flex items-start">
            <AlertCircle size={16} className="text-red-500 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-red-300 font-semibold mb-1">Error al procesar el pago:</p>
              <p className="text-red-200 text-xs">{error}</p>
              <button
                onClick={() => {
                  setError(null);
                  setPaymentStatus('idle');
                }}
                className="text-xs text-red-300 underline mt-2 hover:text-red-200"
              >
                Intentar nuevamente
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Información de seguridad */}
      <div className="text-center">
        <p className="text-xs text-gray-400 mb-1">
          🔒 Pago 100% seguro con MercadoPago
        </p>
        <div className="flex items-center justify-center space-x-2 text-xs text-gray-500">
          <CreditCard size={12} />
          <span>Tarjetas • Efectivo • Transferencia • Hasta 12 cuotas</span>
        </div>
        <p className="text-xs text-green-400 mt-1">
          ⚡ Acceso inmediato después del pago
        </p>
      </div>
    </div>
  );
};

export default AutoPaymentButton;