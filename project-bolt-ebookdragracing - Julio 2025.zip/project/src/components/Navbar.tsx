import React, { useState, useEffect } from 'react';
import { Gauge, Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const sections = [
    { id: 'quarter-mile', name: '1/4 DE MILLA' },
    { id: 'history', name: 'HISTORIA' },
    { id: 'tips', name: 'TIPS' },
    { id: 'preparation', name: 'PREPARACIÓN' },
    { id: 'setup', name: 'SETUP' },
    { id: 'safety', name: 'SEGURIDAD' },
    { id: 'driving', name: 'CONDUCCIÓN' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-race-black/90 backdrop-blur-sm py-2' : 'bg-transparent py-4'
    }`}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        <a href="#" className="flex items-center">
          <Gauge size={28} className="text-race-red mr-2" />
          <span className="font-bebas text-2xl neon-text">AG-42 RACING</span>
        </a>
        
        {/* Desktop navigation */}
        <ul className="hidden md:flex space-x-6">
          {sections.map((section) => (
            <li key={section.id}>
              <a
                href={`#${section.id}`}
                className="font-bebas text-lg hover:text-race-red hover:neon-text transition-all duration-300"
              >
                {section.name}
              </a>
            </li>
          ))}
        </ul>

        {/* CTA Button */}
        <a
          href="#ebook-purchase"
          className="hidden md:block bg-race-red px-4 py-2 font-bebas neon-button"
        >
          DESCARGAR LA GUÍA
        </a>
        
        {/* Mobile menu button */}
        <button 
          className="md:hidden text-race-white focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-race-black/95 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4">
            <ul className="space-y-4">
              {sections.map((section) => (
                <li key={section.id}>
                  <a
                    href={`#${section.id}`}
                    className="block font-bebas text-lg hover:text-race-red hover:neon-text transition-all duration-300"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {section.name}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="#ebook-purchase"
                  className="block bg-race-red px-4 py-2 font-bebas neon-button w-full text-center mt-4"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  DESCARGAR LA GUÍA
                </a>
              </li>
            </ul>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;