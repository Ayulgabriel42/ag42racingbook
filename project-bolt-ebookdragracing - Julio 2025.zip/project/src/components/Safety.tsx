import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';
import AnimatedSection from './AnimatedSection';

interface SafetyItem {
  id: string;
  name: string;
  description: string;
  essential: boolean;
  checked: boolean;
  category: 'personal' | 'vehicle' | 'track';
}

const Safety: React.FC = () => {
  const [safetyItems, setSafetyItems] = useState<SafetyItem[]>([
    {
      id: 'helmet',
      name: 'Casco Homologado',
      description: 'Casco integral homologado. Si bien no es obligatorio que sea certificado/homologado, es lo mas recomendable para mayor protección.',
      essential: true,
      checked: false,
      category: 'personal'
    },
    {
      id: 'suit',
      name: 'Traje Ignífugo',
      description: 'Traje de una pieza homologado para protección contra incendios. (Uso reglamentario en categorías que lo requieran por reglamento)',
      essential: true,
      checked: false,
      category: 'personal'
    },
    {
      id: 'harness',
      name: 'Arnés de Seguridad',
      description: 'Sistema de 3, 4, 5 o 6 puntas según tipo de auto, en vehículos sin modificaciones en su estructura, se puede usar el cinto original de 3 puntas.',
      essential: true,
      checked: false,
      category: 'vehicle'
    },
    {
      id: 'rollcage',
      name: 'Jaula Antivuelco',
      description: 'Estructura de acero que protege el habitáculo en caso de volcadura. Es reglamentario en autos modificados de estructura original o de categorías ALTAS según reglamento.',
      essential: true,
      checked: false,
      category: 'vehicle'
    },
    {
      id: 'extinguisher',
      name: 'Sistema de Extinción',
      description: 'Extintor manual o automatizado, accesible desde interior y exterior del vehículo. Es obligatorio en TODAS las categorías.',
      essential: true,
      checked: false,
      category: 'vehicle'
    },
    {
      id: 'shoes',
      name: 'Calzado Especializado',
      description: 'Botas ignífugas que proporcionan sensibilidad en pedales y protección.',
      essential: false,
      checked: false,
      category: 'personal'
    }
  ]);

  const toggleCheck = (id: string) => {
    setSafetyItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    );
  };

  const essentialChecked = safetyItems.filter(item => item.essential).every(item => item.checked);
  const personalItems = safetyItems.filter(item => item.category === 'personal');
  const vehicleItems = safetyItems.filter(item => item.category === 'vehicle');

  return (
    <AnimatedSection title="SEGURIDAD EN DRAG RACING" id="safety">
      <div className="mb-8">
        <div className="flex items-center justify-center mb-6">
          <ShieldCheck size={28} className="text-race-red mr-2" />
          <h3 className="font-bebas text-2xl">CHECKLIST DE SEGURIDAD</h3>
        </div>
        
        <div 
          className="relative p-6 rounded-lg border border-race-red mb-8 overflow-hidden"
          style={{
            backgroundImage: `url('/59925495_2356007231088972_541901856301907968_n copy copy.jpg')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
        >
          {/* Dark overlay for better text readability */}
          <div className="absolute inset-0 bg-black/75 rounded-lg"></div>
          
          {/* Content with relative positioning to appear above overlay */}
          <div className="relative z-10">
          <h4 className="font-bebas text-xl text-race-red mb-3">LA SEGURIDAD ES PRIMERO</h4>
          <p className="text-lg leading-relaxed mb-4">
            En el 1/4 de milla, las velocidades extremas y la naturaleza competitiva del deporte 
            hacen que la seguridad sea absolutamente crítica. Un accidente a mas 100 km/h puede 
            ser fatal sin el equipamiento de protección adecuado.
          </p>
          <div className="flex items-center space-x-2 text-yellow-400">
            <AlertTriangle size={20} />
            <p className="text-sm font-medium">
              Todos los elementos marcados como "ESENCIAL" son obligatorios para competir
            </p>
          </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Personal Safety Equipment */}
        <div>
          <h4 className="font-bebas text-xl text-race-red mb-4 flex items-center">
            <ShieldCheck size={20} className="mr-2" />
            EQUIPAMIENTO PERSONAL
          </h4>
          <div className="space-y-4">
            {personalItems.map((item) => (
              <motion.div
                key={item.id}
                className={`bg-race-gray p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  item.checked 
                    ? 'border-green-500 bg-green-900/20' 
                    : item.essential 
                      ? 'border-red-500 bg-red-900/20' 
                      : 'border-yellow-500 bg-yellow-900/20'
                } hover:scale-102`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => toggleCheck(item.id)}
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 pt-1">
                    {item.checked ? (
                      <CheckCircle2 className="text-green-500" size={24} />
                    ) : (
                      <XCircle className={item.essential ? 'text-red-500' : 'text-yellow-500'} size={24} />
                    )}
                  </div>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <h5 className="font-bebas text-lg">{item.name}</h5>
                      {item.essential && (
                        <span className="text-xs bg-red-500 text-white px-2 py-1 rounded font-bold">
                          ESENCIAL
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-300 mt-1">{item.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Vehicle Safety Equipment */}
        <div>
          <h4 className="font-bebas text-xl text-race-red mb-4 flex items-center">
            <ShieldCheck size={20} className="mr-2" />
            EQUIPAMIENTO DEL VEHÍCULO
          </h4>
          <div className="space-y-4">
            {vehicleItems.map((item) => (
              <motion.div
                key={item.id}
                className={`bg-race-gray p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  item.checked 
                    ? 'border-green-500 bg-green-900/20' 
                    : item.essential 
                      ? 'border-red-500 bg-red-900/20' 
                      : 'border-yellow-500 bg-yellow-900/20'
                } hover:scale-102`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => toggleCheck(item.id)}
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 pt-1">
                    {item.checked ? (
                      <CheckCircle2 className="text-green-500" size={24} />
                    ) : (
                      <XCircle className={item.essential ? 'text-red-500' : 'text-yellow-500'} size={24} />
                    )}
                  </div>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <h5 className="font-bebas text-lg">{item.name}</h5>
                      {item.essential && (
                        <span className="text-xs bg-red-500 text-white px-2 py-1 rounded font-bold">
                          ESENCIAL
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-300 mt-1">{item.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </AnimatedSection>
  );
};

export default Safety;