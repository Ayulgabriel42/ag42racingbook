import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Gauge } from 'lucide-react';

const Preloader: React.FC = () => {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    // Simulate traffic light sequence
    const timer1 = setTimeout(() => setStage(1), 800); // Red
    const timer2 = setTimeout(() => setStage(2), 1600); // Yellow
    const timer3 = setTimeout(() => setStage(3), 2400); // Green
    
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-50">
      <motion.div
        initial={{ scale: 0.8 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Gauge size={60} className="text-race-red mb-6" />
        <h1 className="font-bebas text-4xl md:text-5xl text-center neon-text">AG-42 RACING</h1>
        <p className="font-roboto text-gray-400 text-center mt-2">eBook 1/4 de Milla</p>
      </motion.div>

      <div className="mt-12 flex space-x-4">
        <motion.div 
          className={`w-12 h-12 rounded-full ${stage >= 1 ? 'bg-red-600' : 'bg-gray-800'}`}
          animate={{ 
            scale: stage === 1 ? [1, 1.1, 1] : 1,
            boxShadow: stage >= 1 ? '0 0 20px #FF0000' : 'none'
          }}
          transition={{ duration: 0.3 }}
        />
        <motion.div 
          className={`w-12 h-12 rounded-full ${stage >= 2 ? 'bg-yellow-500' : 'bg-gray-800'}`}
          animate={{ 
            scale: stage === 2 ? [1, 1.1, 1] : 1,
            boxShadow: stage >= 2 ? '0 0 20px #FFC107' : 'none'
          }}
          transition={{ duration: 0.3 }}
        />
        <motion.div 
          className={`w-12 h-12 rounded-full ${stage >= 3 ? 'bg-green-500' : 'bg-gray-800'}`}
          animate={{ 
            scale: stage === 3 ? [1, 1.1, 1] : 1,
            boxShadow: stage >= 3 ? '0 0 20px #4CAF50' : 'none'
          }}
          transition={{ duration: 0.3 }}
        />
      </div>

      <motion.p 
        className="mt-8 text-gray-400"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        {stage < 3 ? 'Preparando contenido...' : '¡Listo para correr!'}
      </motion.p>
    </div>
  );
};

export default Preloader;