import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, User, Mail, MessageSquare, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';

const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [charCount, setCharCount] = useState(0);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    if (name === 'message') {
      if (value.length <= 1000) {
        setFormData(prev => ({ ...prev, [name]: value }));
        setCharCount(value.length);
      }
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const validateForm = () => {
    if (!formData.name.trim()) {
      setError('El nombre es requerido');
      return false;
    }
    
    if (!formData.email.trim()) {
      setError('El email es requerido');
      return false;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Formato de email inválido');
      return false;
    }
    
    if (!formData.message.trim()) {
      setError('El mensaje es requerido');
      return false;
    }
    
    if (formData.message.length > 1000) {
      setError('El mensaje no puede exceder 1000 caracteres');
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setStatus('sending');
    setError(null);

    try {
      console.log('📤 Enviando consulta via Netlify Forms:', formData);

      // Crear FormData para Netlify Forms
      const netlifyFormData = new FormData();
      netlifyFormData.append('form-name', 'consultas-ag42');
      netlifyFormData.append('name', formData.name);
      netlifyFormData.append('email', formData.email);
      netlifyFormData.append('message', formData.message);
      netlifyFormData.append('timestamp', new Date().toLocaleString('es-AR'));
      netlifyFormData.append('source', 'AG-42 Racing eBook');

      const response = await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(netlifyFormData as any).toString()
      });

      console.log('📥 Respuesta de Netlify:', response.status, response.statusText);

      if (response.ok) {
        console.log('✅ Consulta enviada exitosamente');
        setStatus('success');
        
        // Limpiar formulario después de 3 segundos
        setTimeout(() => {
          setFormData({ name: '', email: '', message: '' });
          setCharCount(0);
          setStatus('idle');
        }, 3000);
      } else {
        throw new Error(`Error del servidor: ${response.status}`);
      }

    } catch (err) {
      console.error('❌ Error al enviar consulta:', err);
      const errorMessage = err instanceof Error ? err.message : 'Error desconocido al enviar la consulta';
      setError(errorMessage);
      setStatus('error');
    }
  };

  const getButtonContent = () => {
    switch (status) {
      case 'sending':
        return (
          <>
            <Loader2 size={20} className="animate-spin" />
            <span>ENVIANDO...</span>
          </>
        );
      case 'success':
        return (
          <>
            <CheckCircle size={20} />
            <span>¡ENVIADO!</span>
          </>
        );
      case 'error':
        return (
          <>
            <AlertCircle size={20} />
            <span>REINTENTAR</span>
          </>
        );
      default:
        return (
          <>
            <Send size={20} />
            <span>ENVIAR CONSULTA</span>
          </>
        );
    }
  };

  const getButtonColor = () => {
    switch (status) {
      case 'success':
        return 'from-green-600 to-green-700 hover:from-green-700 hover:to-green-800';
      case 'error':
        return 'from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800';
      case 'sending':
        return 'from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800';
      default:
        return 'from-race-red to-red-600 hover:from-red-600 hover:to-race-red';
    }
  };

  return (
    <div>
      <form 
        onSubmit={handleSubmit} 
        className="space-y-4"
        name="consultas-ag42"
        method="POST"
        data-netlify="true"
        data-netlify-honeypot="bot-field"
      >
        {/* Campo oculto para Netlify Forms */}
        <input type="hidden" name="form-name" value="consultas-ag42" />
        
        {/* Honeypot para spam protection */}
        <div style={{ display: 'none' }}>
          <label>
            No llenar este campo si eres humano: <input name="bot-field" />
          </label>
        </div>

        {/* Campo Nombre */}
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
            <User size={16} className="inline-block mr-2 text-race-red" />
            Nombre *
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            placeholder="Tu nombre completo"
            className="w-full p-3 bg-race-black border border-gray-700 rounded-lg focus:outline-none focus:border-race-red transition-colors"
            disabled={status === 'sending'}
            required
          />
        </div>

        {/* Campo Email */}
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
            <Mail size={16} className="inline-block mr-2 text-race-red" />
            Email *
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="tu@email.com"
            className="w-full p-3 bg-race-black border border-gray-700 rounded-lg focus:outline-none focus:border-race-red transition-colors"
            disabled={status === 'sending'}
            required
          />
        </div>

        {/* Campo Mensaje */}
        <div>
          <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
            <MessageSquare size={16} className="inline-block mr-2 text-race-red" />
            Consulta *
          </label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleInputChange}
            placeholder="Escribe tu consulta aquí... (máximo 1000 caracteres)"
            rows={5}
            className="w-full p-3 bg-race-black border border-gray-700 rounded-lg focus:outline-none focus:border-race-red transition-colors resize-none"
            disabled={status === 'sending'}
            required
          />
          <div className="flex justify-between items-center mt-1">
            <span className="text-xs text-gray-500">* Campos obligatorios</span>
            <span className={`text-xs ${charCount > 900 ? 'text-orange-400' : charCount > 950 ? 'text-red-400' : 'text-gray-500'}`}>
              {charCount}/1000 caracteres
            </span>
          </div>
        </div>

        {/* Botón de envío */}
        <motion.button
          type="submit"
          disabled={status === 'sending' || status === 'success'}
          className={`w-full bg-gradient-to-r ${getButtonColor()} text-white font-bebas text-lg py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg flex items-center justify-center space-x-3 neon-button ${
            status === 'sending' || status === 'success' ? 'opacity-75 cursor-not-allowed' : ''
          }`}
          whileHover={status === 'idle' || status === 'error' ? { scale: 1.02 } : {}}
          whileTap={status === 'idle' || status === 'error' ? { scale: 0.98 } : {}}
        >
          {getButtonContent()}
        </motion.button>
      </form>

      {/* Mensajes de estado */}
      {status === 'success' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 p-3 bg-green-900/30 border border-green-500 rounded-lg text-center"
        >
          <p className="text-green-300 text-sm">
            ✅ ¡Consulta enviada exitosamente! Te responderemos a la brevedad.
          </p>
          <p className="text-green-400 text-xs mt-1">
            📧 Recibirás una notificación en tu email de confirmación
          </p>
        </motion.div>
      )}

      {error && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 p-3 bg-red-900/30 border border-red-500 rounded-lg"
        >
          <div className="flex items-start">
            <AlertCircle size={16} className="text-red-500 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-red-300 font-semibold mb-1">Error al enviar consulta:</p>
              <p className="text-red-200 text-xs">{error}</p>
              <button
                onClick={() => {
                  setError(null);
                  setStatus('idle');
                }}
                className="text-xs text-red-300 underline mt-2 hover:text-red-200"
              >
                Intentar nuevamente
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Información adicional */}
      <div className="mt-4 text-center">
        <p className="text-xs text-gray-400 mb-1">
          📧 Responderemos a tu consulta en menos de 24 horas
        </p>
        <p className="text-xs text-gray-500">
          🔒 Tu información está protegida y no será compartida
        </p>
      </div>
    </div>
  );
};

export default ContactForm;