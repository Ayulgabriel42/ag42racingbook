import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import QuarterMile from './components/QuarterMile';
import History from './components/History';
import Tips from './components/Tips';
import Preparation from './components/Preparation';
import Setup from './components/Setup';
import Safety from './components/Safety';
import Driving from './components/Driving';
import Footer from './components/Footer';
import BackToTop from './components/BackToTop';
import Preloader from './components/Preloader';

function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {loading ? (
        <Preloader />
      ) : (
        <div className="min-h-screen bg-race-black">
          <Navbar />
          <Hero />
          <div className="container mx-auto px-4 md:px-8 section-spacing">
            <QuarterMile />
            <div className="section-separator my-20 mx-auto w-3/4"></div>
            <History />
            <div className="section-separator my-20 mx-auto w-3/4"></div>
            <Tips />
            <div className="section-separator my-20 mx-auto w-3/4"></div>
            <Preparation />
            <div className="section-separator my-20 mx-auto w-3/4"></div>
            <Setup />
            <div className="section-separator my-20 mx-auto w-3/4"></div>
            <Safety />
            <div className="section-separator my-20 mx-auto w-3/4"></div>
            <Driving />
          </div>
          <Footer />
          <BackToTop />
        </div>
      )}
    </>
  );
}

export default App;